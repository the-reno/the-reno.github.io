#!/usr/bin/env python3
"""Three parts boards: imperial stock/hardware and metric cuts, from V4 CAD."""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import json, csv, subprocess
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PIL import Image

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'deliverables';OUT.mkdir(exist_ok=True)
DATA=json.loads((ROOT/'parts-data-reviewed.json').read_text())
PARTS={r['id']:r for r in DATA['parts']}
PW,PH=A4
BG=colors.HexColor('#fafaf5');INK=colors.HexColor('#233537');MUTED=colors.HexColor('#5e6e6f')
LINE=colors.HexColor('#cbd3ce');WOOD=colors.HexColor('#be996a');TEAL=colors.HexColor('#245c61')
SOFT=colors.HexColor('#e7efec');AMBER=colors.HexColor('#98621e');WHITE=colors.white
for name,fn in [('PartSans','DejaVuSans.ttf'),('PartBold','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+fn))
pdfmetrics.registerFontFamily('PartSans',normal='PartSans',bold='PartBold',italic='PartSans',boldItalic='PartBold')
BODY=ParagraphStyle('body',fontName='PartSans',fontSize=10.2,leading=13.4,textColor=INK)
SMALL=ParagraphStyle('small',parent=BODY,fontSize=9,leading=11.7,textColor=MUTED)
PDF=OUT/'garage-door-parts-centimeters.pdf'
c=canvas.Canvas(str(PDF),pagesize=A4)
c.setTitle('Garage door - imperial stock and hardware; cuts in centimeters')
c.setAuthor('Garage door design collaboration')
AUDIT=[]
PAGE=0

def txt(x,y,s,sz=11,bold=False,col=INK,align='left'):
    c.setFont('PartBold' if bold else 'PartSans',sz);c.setFillColor(col)
    getattr(c,{'left':'drawString','right':'drawRightString','center':'drawCentredString'}[align])(x,y,str(s))

def para(s,x,top,w,style=BODY,minimum=0):
    p=Paragraph(s,style);_,h=p.wrap(w,1000);p.drawOn(c,x,top-h)
    AUDIT.append({'page':PAGE,'kind':'paragraph','text':s,'box':[x,top-h,w,h]})
    if top-h<minimum:raise ValueError((s,'below minimum',top-h,minimum))
    return top-h

def line(x1,y1,x2,y2,col=LINE,w=.7):
    c.setLineWidth(w);c.setStrokeColor(col);c.line(x1,y1,x2,y2)

def rect(x,y,w,h,fill=WHITE,stroke=None):
    if fill:c.setFillColor(fill)
    if stroke:c.setStrokeColor(stroke)
    c.setLineWidth(.7);c.rect(x,y,w,h,fill=bool(fill),stroke=bool(stroke))

def fmt(v):
    return str(Decimal(str(v)).quantize(Decimal('.001'),rounding=ROUND_HALF_UP)).rstrip('0').rstrip('.')

def dims(p):
    a=p['exact_cm']
    if p['id'] in ('F1','F2','P1','P3','S1'):
        return 'Cut length: '+fmt(a['length'])+' cm'
    return 'Cut: '+' × '.join(fmt(a[k]) for k in ('length','width'))+' cm'

def start(title,subtitle,page_n):
    global PAGE
    PAGE=page_n
    rect(0,0,PW,PH,BG)
    txt(24,815,'GARAGE DOOR  /  IMPERIAL STOCK + METRIC CUTS',9.1,True,MUTED)
    txt(PW-24,815,f'{page_n} / 3',10,True,MUTED,'right')
    txt(24,784,title,25,True)
    txt(24,758,'QTY = total for BOTH doors',12,True,TEAL)
    txt(24,739,subtitle,10.2,col=MUTED)

def end(note):
    line(24,59,PW-24,59)
    para(note,24,49,PW-48,SMALL,minimum=13)
    c.showPage()

CFG={
 'F1':('Frame uprights','2 × 4 timber; actual 1-1/2 × 3-1/2 in','CUT ONLY IF REPLACING','Keep stock width. Cut length and <b>3 half-laps</b>. Keep sound existing members.'),
 'F2':('Frame cross rails','2 × 4 timber; actual 1-1/2 × 3-1/2 in','CUT ONLY IF REPLACING','Keep stock width. Cut <b>full leaf width</b> and 2 end half-laps; retain sound rails.'),
 'P1':('Outside main panels','15/32 in exterior plywood; 4 ft wide','YES - CUT HEIGHT','Shorten to the shown length. Keep the actual usable stock width.'),
 'P2':('Outside infill strips','15/32 in matching exterior plywood','YES - CUT TO SIZE','Cut width and length unless your existing strips fit. Support on timber.'),
 'P3':('Inside main panels','1/5 in inner plywood; 4 ft wide','YES - CUT HEIGHT','Shorten to the shown length. Keep the actual usable stock width.'),
 'P4':('Inside infill strips','1/5 in matching inner plywood','YES - CUT TO SIZE','Cut width and length unless your existing strips fit. Support on timber.'),
 'I1':('Insulation inserts','1-1/2 in rigid foam','YES - CUT RECTANGLES','Cut length and width. Fit flush in the actual frame cavities.'),
 'T1':('Vertical white trim','Model thickness: approx. 0.236 in*','YES - CUT TO SIZE','Cut length and width. One at each vertical edge of each door.'),
 'T2':('Horizontal white trim','Model thickness: approx. 0.236 in*','YES - CUT TO SIZE','Cut length and width. Three between the vertical trims on each door.'),
 'C1':('White center cover','Model thickness: approx. 0.236 in*','YES - CUT AND FIT','Cut length and width; fit both ends. Attach to the <b>RIGHT door only</b>.'),
 'C2':('Center-cover spacer','Model thickness: approx. 0.118 in*','YES - CUT AND FIT','Cut length and width. Thickness follows the selected gasket; <b>RIGHT only</b>.'),
 'S1':('Center rubber seal','Model section: 0.866 × 0.118 in**','CUT TO LENGTH ONLY','Choose the seal profile, then cut its length. <b>Do not cut its width</b> to this model.'),
}

def part_card(ident,index):
    row,col=divmod(index,2);x=24+col*281.6;top=721-row*219.5;w=265.6;h=207.5
    rect(x,top-h,w,h,WHITE,LINE)
    p=PARTS[ident];title,material,status,cut=CFG[ident]
    txt(x+11,top-20,ident,10.5,True,TEAL)
    # Title and quantity occupy explicit non-overlapping horizontal ranges.
    fs=12.4
    while pdfmetrics.stringWidth(title,'PartBold',fs)>w-105:fs-=.2
    txt(x+37,top-20,title,fs,True)
    txt(x+w-11,top-20,f'× {p["quantity_pair"]}',16,True,TEAL,'right')
    material_fs=9.5
    while pdfmetrics.stringWidth(material,'PartSans',material_fs)>w-22:material_fs-=.1
    txt(x+11,top-38,material,material_fs,col=MUTED)
    c.drawImage(str(ROOT/'thumbnails'/f'{ident}.png'),x+8,top-108,w-16,(w-16)*180/750,mask='auto')
    dd=dims(p);fs=12.8
    while pdfmetrics.stringWidth(dd,'PartBold',fs)>w-22:fs-=.2
    txt(x+11,top-130,dd,fs,True)
    txt(x+11,top-151,status,10.3,True,AMBER if ident.startswith('F') else TEAL)
    para(cut,x+11,top-161,w-22,BODY,minimum=top-h+7)
    AUDIT.append({'page':PAGE,'id':ident,'quantity':p['quantity_pair'],'stock_imperial':material,'cut_label_cm':dd,'box':[x,top-h,w,h]})

start('1. Frame and plywood','Stock in inches / feet. Cut lengths in cm; keep stock widths where stated.',1)
for i,ident in enumerate(['F1','F2','P1','P2','P3','P4']):part_card(ident,i)
end('Half-lap cuts: 8.89 cm long × 1.905 cm deep for the stated stock. Mark from actual timber. Pictures use separate scales. Decimal precision is not a cutting tolerance.')

start('2. Insulation, trim and joint','Stock thickness in inches. Cut length × width in cm; seal is length only.',2)
for i,ident in enumerate(['I1','T1','T2','C1','C2','S1']):part_card(ident,i)
end('*Model thicknesses are not exactly 1/4 in or 1/8 in; measure actual stock. **Seal section is a compressed model, not a purchase specification. Confirm all cuts on the actual door.')

def hardware_drawing(kind,x,y,w,h):
    # Schematic line illustrations identify function; no product dimensions or drilling patterns.
    c.saveState();c.translate(x+w/2,y+h/2)
    c.setStrokeColor(INK);c.setFillColor(INK);c.setLineWidth(2)
    if kind=='hinge':
        rect(-98,-9,181,18,INK);rect(-108,-27,10,54,INK)
        for xx in[-71,-18,48]:c.setFillColor(BG);c.circle(xx,0,3,fill=1,stroke=0)
    elif kind=='pull':
        c.setLineWidth(7);c.setLineCap(1)
        c.line(-62,-9,-62,15);c.line(-62,15,62,15);c.line(62,15,62,-9)
        for xx in[-62,62]:c.setFillColor(INK);c.circle(xx,-9,9,fill=1,stroke=0)
    elif kind=='latch':
        rect(-76,-16,96,32,INK);rect(39,-19,25,38,INK)
        c.setStrokeColor(BG);c.setLineWidth(5);c.line(-48,0,54,0)
        c.setStrokeColor(INK);c.line(-33,0,-33,21);c.line(-33,21,-17,21)
    elif kind=='bolt':
        # Keep the schematic horizontal so it remains inside the illustration box.
        rect(-65,-14,77,28,INK)
        c.setStrokeColor(MUTED);c.setLineWidth(6);c.line(-43,0,62,0);c.line(-43,0,-43,21)
        rect(57,-13,19,26,None,INK)
    elif kind=='holdback':
        rect(-96,-22,21,44,INK);rect(70,-22,21,44,INK)
        c.setStrokeColor(INK);c.setLineWidth(5);c.line(-84,0,7,23);c.line(7,23,80,0)
        for xx,yy in[(-84,0),(7,23),(80,0)]:c.setFillColor(MUTED);c.circle(xx,yy,6,fill=1,stroke=0)
    elif kind=='seals':
        for dy in[-21,1,23]:
            c.setFillColor(INK);c.roundRect(-95,dy,180,8,4,fill=1,stroke=0)
            c.setFillColor(MUTED);c.ellipse(79,dy,93,dy+8,fill=1,stroke=0)
    c.restoreState()

HW=[
 ('H1','Load-bearing hinges','6','hinge','Size in inches: to select','NO METAL CUTTING','Three per leaf shown. Confirm rating and timber backing before mounting.'),
 ('H2','Door pulls','2','pull','Size in inches: to select','NO PART CUTTING','Use factory parts. Drill mounting holes to the selected template.'),
 ('H3','Latch arrangement','1','latch','Size in inches: to select','NO PART CUTTING','Right active door. Fix to solid timber; fit to the selected template.'),
 ('H4','Left-door bolts','2','bolt','Size in inches: to select','NO PART CUTTING','One top and one bottom on the left leaf. Fit keepers to sound supports.'),
 ('H5','Hold-open devices','2','holdback','Size in inches: to select','NO PART CUTTING','One per leaf. Select and position for the actual outward swing.'),
 ('H6','Perimeter seals','5 runs','seals','Cuts: head 257; sides 216 cm','YES - CUT TO FIT','Sides: <b>2 runs</b>. Bottoms: <b>2 × 127.565 cm</b> reference. Select profiles; measure final cuts.'),
]
start('3. Hardware and edge seals','Imperial product sizes. Schematic examples; hardware remains to be selected.',3)
for i,(ident,title,qty,kind,size,status,note) in enumerate(HW):
    row,col=divmod(i,2);x=24+col*281.6;top=721-row*219.5;w=265.6;h=207.5
    rect(x,top-h,w,h,WHITE,LINE)
    txt(x+11,top-20,ident,10.5,True,TEAL)
    fs=12.4
    while pdfmetrics.stringWidth(title,'PartBold',fs)>w-(133 if ident=='H6' else 105):fs-=.2
    txt(x+37,top-20,title,fs,True)
    txt(x+w-11,top-20,f'× {qty}',13.3,True,TEAL,'right')
    hardware_drawing(kind,x+12,top-110,w-24,68)
    txt(x+11,top-130,size,11.2,True)
    txt(x+11,top-151,status,10.3,True,TEAL)
    para(note,x+11,top-161,w-22,BODY,minimum=top-h+7)
end('Seal lengths are planning runs, not final cuts. Extra blocking, screws, adhesives and coatings depend on the actual frame and selected products; their quantities are not fixed.')
c.save()

names=['garage-door-parts-01-frame-plywood-cm','garage-door-parts-02-trim-insulation-cm','garage-door-parts-03-hardware-cm']
for i,name in enumerate(names,1):
    temp=OUT/(name+'.render')
    for attempt in range(3):
        subprocess.run(['pdftoppm','-r','220','-f',str(i),'-l',str(i),'-singlefile','-png',str(PDF),str(temp)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            with Image.open(str(temp)+'.png')as im:im.load()
            with Image.open(str(temp)+'.png')as im:im.verify()
            Path(str(temp)+'.png').replace(OUT/(name+'.png'))
            break
        except (OSError,SyntaxError):
            if attempt==2:raise

# Cut values remain exact. Imperial stock labels are separate from metric cuts.
# Full exact model geometry, including material thickness, remains in reviewed JSON.
with (OUT/'garage-door-parts-exact-cm.csv').open('w',newline='')as f:
    w=csv.writer(f);w.writerow(['part_id','part','quantity_both_doors','stock_imperial','length_cm','width_cm','dimension_use','cut_status','cuts'])
    for p in DATA['parts']:
        a=p['exact_cm_decimal'];cfg=CFG[p['id']]
        usage='Cut length and width'
        width=a['width']
        if p['id'] in ('F1','F2','P1','P3'):
            usage='Cut length; width is finished reference from retained stock'
        elif p['id']=='S1':
            usage='Cut length only; select factory seal width from imperial stock reference'
            width=''
        w.writerow([p['id'],cfg[0],p['quantity_pair'],cfg[1],a['length'],width,usage,cfg[2],cfg[3].replace('<b>','').replace('</b>','')])
(ROOT/'parts-sheets-layout-audit.json').write_text(json.dumps({'pages':3,'quantity_scope':'both doors','base_material_parts':34,'center_gasket':1,'page_items':AUDIT},indent=2))
print(json.dumps({'pdf':str(PDF),'images':[str(OUT/(n+'.png'))for n in names],'pages':3,'part_types':12,'scheduled_pieces_with_gasket':35},indent=2))
