#!/usr/bin/env python3
"""Render exact V4 CAD-mesh parts for centimeter-labelled part cards.

Geometry is read without modification from cad/preview_mesh.json.  Each PNG is
one orthographic view of one component, with independently fitted scale.  No
dimension labels, quantities or implied cutting instructions are painted here.
The two timber parts are turned so their machined half-lap faces are visible.
"""
from pathlib import Path
import json
import math
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent / "thumbnails"
MESH = ROOT / "cad" / "preview_mesh.json"
W, H, AA = 750, 180, 3
BG = (250, 250, 246)

PARTS = [
    ("F1", "LEFT_INACTIVE_FRAME_STILE_HINGE", "long", "front", (208, 166, 110)),
    ("F2", "LEFT_INACTIVE_FRAME_RAIL_BOTTOM", "rail", "rear", (208, 166, 110)),
    ("P1", "LEFT_INACTIVE_EXTERIOR_SKIN_MAIN", "sheet", "front", (223, 203, 165)),
    ("P2", "LEFT_INACTIVE_EXTERIOR_SKIN_INFILL", "long", "front", (223, 203, 165)),
    ("P3", "LEFT_INACTIVE_INTERIOR_SKIN_MAIN", "sheet", "front", (237, 221, 190)),
    ("P4", "LEFT_INACTIVE_INTERIOR_SKIN_INFILL", "long", "front", (237, 221, 190)),
    ("I1", "LEFT_INACTIVE_FOAM_1", "foam", "front", (131, 181, 190)),
    ("T1", "LEFT_INACTIVE_TRIM_STILE_HINGE", "long", "front", (241, 238, 223)),
    ("T2", "LEFT_INACTIVE_TRIM_RAIL_BOTTOM", "rail", "front", (241, 238, 223)),
    ("C1", "RIGHT_ACTIVE_CENTER_COVER", "long", "front", (241, 238, 223)),
    ("C2", "RIGHT_ACTIVE_CENTER_SPACER", "long", "front", (217, 201, 169)),
    ("S1", "REFERENCE_RIGHT_ACTIVE_COMPRESSED_GASKET", "long", "front", (55, 65, 63)),
]


def normalized(v):
    a = np.array(v, dtype=float)
    return a / np.linalg.norm(a)


def local_vertices(vertices, kind, face):
    """Rigid axis permutation/reflection only: absolutely no shape distortion."""
    v = np.asarray(vertices, dtype=float)
    if kind in ("rail", "foam"):
        xyz = v[:, [0, 2, 1]].copy()
    else:
        xyz = v[:, [2, 0, 1]].copy()
    if face == "front":
        xyz[:, 2] *= -1
    xyz -= (xyz.max(axis=0) + xyz.min(axis=0)) / 2
    return xyz


def triangle_normals(vertices, triangles):
    vv = vertices[triangles]
    nn = np.cross(vv[:, 1] - vv[:, 0], vv[:, 2] - vv[:, 0])
    nn /= np.linalg.norm(nn, axis=1)[:, None]
    return nn


def physical_edges(vertices, triangles):
    """Weld face-local vertices and retain only creases/boundary silhouette edges."""
    normals = triangle_normals(vertices, triangles)
    edges = {}
    for tri, n in zip(triangles, normals):
        for j in range(3):
            a, b = vertices[tri[j]], vertices[tri[(j + 1) % 3]]
            ka, kb = tuple(np.round(a, 6)), tuple(np.round(b, 6))
            key = tuple(sorted([ka, kb]))
            edges.setdefault(key, []).append(n)
    result = []
    for (a, b), normals in edges.items():
        if len(normals) == 1 or any(abs(np.dot(normals[0], n)) < .995 for n in normals[1:]):
            result.append([a, b])
    return np.array(result, dtype=float)


def render(part_id, part, kind, face, base):
    v = local_vertices(part["vertices"], kind, face)
    tt = np.asarray(part["triangles"], dtype=int)
    # A shallow broad-face angle keeps sheets legible inside a wide short card.
    camera = normalized((.25, -1, .33) if kind in ("sheet", "foam") else (.14, -1, 1.50))
    right = normalized(np.cross([0, 0, 1], camera))
    up = np.cross(camera, right)
    basis = np.array([right, up, camera])
    pp = v @ basis.T
    low, high = pp[:, :2].min(axis=0), pp[:, :2].max(axis=0)
    width, height = (W - 58) * AA, (H - 44) * AA
    scale = min(width / (high[0] - low[0]), height / (high[1] - low[1]))
    center = (low + high) / 2
    iw, ih = W * AA, H * AA

    def project(points):
        p = points @ basis.T
        p[:, 0] = (p[:, 0] - center[0]) * scale + iw / 2
        p[:, 1] = -(p[:, 1] - center[1]) * scale + ih / 2 - 3 * AA
        return p

    points = project(v)
    depth = np.full((ih, iw), -np.inf)
    rgba = np.zeros((ih, iw, 4), dtype=np.uint8)
    light = normalized((-.45, -.55, 1.5))
    # Use normal magnitudes for robust colouring across reflected coordinates.
    # All opaque faces participate in depth rasterization; no painter-order error.
    for tri, local_tri in zip(points[tt], v[tt]):
        xlo = max(0, int(np.floor(tri[:, 0].min())))
        xhi = min(iw - 1, int(np.ceil(tri[:, 0].max())))
        ylo = max(0, int(np.floor(tri[:, 1].min())))
        yhi = min(ih - 1, int(np.ceil(tri[:, 1].max())))
        if xlo > xhi or ylo > yhi:
            continue
        (x1, y1, z1), (x2, y2, z2), (x3, y3, z3) = tri
        den = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3)
        if abs(den) < 1e-10:
            continue
        yy, xx = np.mgrid[ylo:yhi + 1, xlo:xhi + 1]
        a = ((y2 - y3) * (xx + .5 - x3) + (x3 - x2) * (yy + .5 - y3)) / den
        b = ((y3 - y1) * (xx + .5 - x3) + (x1 - x3) * (yy + .5 - y3)) / den
        c = 1 - a - b
        zz = a * z1 + b * z2 + c * z3
        dr = depth[ylo:yhi + 1, xlo:xhi + 1]
        mask = (a >= -1e-8) & (b >= -1e-8) & (c >= -1e-8) & (zz > dr)
        dr[mask] = zz[mask]
        n = normalized(np.cross(local_tri[1] - local_tri[0], local_tri[2] - local_tri[0]))
        brightness = .73 + .27 * abs(float(np.dot(n, light)))
        rgb = np.asarray(base, dtype=float) * brightness
        # Very subtle grain on wide timber/plywood faces, without adding geometry.
        if part_id[0] in ("F", "P") and abs(n[2]) > .9:
            local_x = a * local_tri[0, 0] + b * local_tri[1, 0] + c * local_tri[2, 0]
            local_y = a * local_tri[0, 1] + b * local_tri[1, 1] + c * local_tri[2, 1]
            grain = np.sin(local_y * .16 + np.sin(local_x * .004) * .55) * 1.0
            tex = np.clip(rgb[None, None, :] + grain[:, :, None], 0, 255).astype(np.uint8)
            rgba[ylo:yhi + 1, xlo:xhi + 1, :3][mask] = tex[mask]
        else:
            rgba[ylo:yhi + 1, xlo:xhi + 1, :3][mask] = rgb.clip(0, 255).astype(np.uint8)
        rgba[ylo:yhi + 1, xlo:xhi + 1, 3][mask] = 255

    # Depth-tested fine crease edges make the half-lap shoulders unambiguous.
    edge_color = tuple((np.asarray(base) * .60).astype(np.uint8)) + (255,)
    edge_radius = .43 * AA
    for edge in physical_edges(v, tt):
        a, b = project(edge)
        count = max(2, int(np.linalg.norm(b[:2] - a[:2]) * 1.5))
        for t in np.linspace(0, 1, count):
            p = a * (1 - t) + b * t
            cx, cy = int(p[0]), int(p[1])
            if not (0 <= cx < iw and 0 <= cy < ih):
                continue
            # A one-pixel depth tolerance keeps a front silhouette visible.
            if p[2] < depth[cy, cx] - 1.5 / scale:
                continue
            rr = int(math.ceil(edge_radius))
            for dx in range(-rr, rr + 1):
                for dy in range(-rr, rr + 1):
                    px, py = cx + dx, cy + dy
                    if dx * dx + dy * dy <= edge_radius * edge_radius and 0 <= px < iw and 0 <= py < ih:
                        if p[2] >= depth[py, px] - 1.5 / scale:
                            rgba[py, px] = edge_color

    model = Image.fromarray(rgba, mode="RGBA")
    # A soft, low-opacity shadow sits behind the one rendered part.
    alpha = model.getchannel("A")
    shadow_mask = alpha.filter(ImageFilter.GaussianBlur(3.5 * AA)).point(lambda p: int(p * .12))
    shadow = Image.new("RGBA", (iw, ih), (36, 37, 30, 0))
    shadow.putalpha(shadow_mask)
    canvas = Image.new("RGBA", (iw, ih), (0, 0, 0, 0))
    canvas.alpha_composite(shadow, (1 * AA, 6 * AA))
    canvas.alpha_composite(model)
    canvas = canvas.resize((W, H), Image.Resampling.LANCZOS)
    path = OUT / f"{part_id}.png"
    canvas.save(path)
    world_bounds = part["bounds_mm"]
    sizes = {q: round((world_bounds[q + "max"] - world_bounds[q + "min"]) / 10, 8) for q in "xyz"}
    bbox = canvas.getbbox()
    return {
        "id": part_id, "source_component": part["name"], "file": str(path),
        "image_pixels": [W, H], "alpha_content_bbox_px": bbox,
        "source_bounds_cm_xyz": sizes,
        "source_blank_cm": [x / 10 for x in part["blank_dimensions_mm"]] if part.get("blank_dimensions_mm") else None,
        "source_triangle_count": len(tt), "display_face": face,
        "orthographic_camera_local": camera.tolist(),
        "mm_per_final_pixel": AA / scale,
        "note": "One actual CAD component. Orthographic view; independently fitted scale. No dimensions altered."
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    source = json.loads(MESH.read_text())
    parts = {p["name"]: p for p in source["parts"]}
    manifest = [render(i, parts[n], k, f, c) for i, n, k, f, c in PARTS]
    (OUT / "manifest.json").write_text(json.dumps({
        "source_mesh": str(MESH), "units": "cm", "parts": manifest,
        "rendering": "Exact source triangles; rigid axis orientation; orthographic projection; per-pixel depth buffer; 3x supersampling.",
        "gasket_note": "S1 depicts only the provisional compressed envelope; a selected product profile is not yet available."
    }, indent=2) + "\n")
    # Review sheet only: equal card-size placement, no scale equivalence implied.
    sheet = Image.new("RGB", (W * 2, H * 6), BG)
    for index, entry in enumerate(manifest):
        im = Image.open(entry["file"])
        sheet.paste(im, ((index % 2) * W, (index // 2) * H), im)
    sheet.save(OUT / "review-sheet.png")
    for entry in manifest:
        print(entry["id"], entry["file"], entry["alpha_content_bbox_px"], entry["source_bounds_cm_xyz"])


if __name__ == "__main__":
    main()
