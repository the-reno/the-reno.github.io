#!/usr/bin/env python3
"""Deterministic assembly illustrations from the V4 CAD triangle mesh.

All components preserve source geometry and dimensions.  Only rigid camera,
explosion and hinge transforms are applied.  Hardware products are not shown.
The PNGs carry no dimensional or instruction text; metadata supplies anchors.
"""
from pathlib import Path
import json, math, hashlib
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SOURCE = ROOT / "cad" / "preview_mesh.json"
DERIVED = ROOT / "cad" / "derived_dimensions.json"
W, H, AA = 1600, 1100, 2
LEFT, RIGHT = "LEFT_INACTIVE", "RIGHT_ACTIVE"
COLORS = {
    "timber": (207, 164, 111), "plywood_exterior": (225, 208, 178),
    "plywood_interior": (235, 220, 190), "foam": (132, 191, 199),
    "trim": (242, 242, 232), "spacer": (218, 205, 174),
    "cover": (245, 243, 235), "gasket_reference": (63, 75, 73),
    "jamb_reference": (216, 219, 211), "stop_reference": (207, 213, 206),
}
WORK_OUT = np.array([[1, 0, 0], [0, 0, 1], [0, -1, 0]], dtype=float)
WORK_IN = np.array([[-1, 0, 0], [0, 0, 1], [0, 1, 0]], dtype=float)
# Both transforms are proper rotations.  The hinge edge swaps on turning over.

def unit(a):
    a = np.asarray(a, dtype=float)
    return a / np.linalg.norm(a)

def normals(v, tt):
    q = v[tt]
    n = np.cross(q[:, 1] - q[:, 0], q[:, 2] - q[:, 0])
    return n / np.linalg.norm(n, axis=1)[:, None]

def crease_edges(v, tt):
    pool = {}
    for tri, n in zip(tt, normals(v, tt)):
        for k in range(3):
            a, b = (tuple(np.round(v[tri[m]], 7)) for m in (k, (k + 1) % 3))
            pool.setdefault(tuple(sorted((a, b))), []).append(n)
    return np.array([[a, b] for (a, b), nn in pool.items()
                     if len(nn) == 1 or any(abs(np.dot(nn[0], q)) < .995 for q in nn[1:])])

def role_id(part):
    n, r = part["name"], part["role"]
    if r == "frame_stile": return "F1"
    if r == "frame_rail": return "F2"
    if r == "skin_exterior": return "P2" if n.endswith("INFILL") else "P1"
    if r == "skin_interior": return "P4" if n.endswith("INFILL") else "P3"
    if r == "insulation": return "I1"
    if r == "decorative_trim_stile": return "T1"
    if r == "decorative_trim_rail": return "T2"
    return {"center_cover": "C1", "center_spacer": "C2", "gasket_reference": "S1"}.get(r, r)

def is_material(p):
    return not p["is_reference"] or p["role"] == "gasket_reference"

def all_left(p):
    return p["leaf"] == LEFT and is_material(p)

def frame(p):
    return all_left(p) and p["role"].startswith("frame_")

def through_outside(p):
    return all_left(p) and (p["role"].startswith("frame_") or p["role"] == "skin_exterior")

def through_foam(p):
    return through_outside(p) or (all_left(p) and p["role"] == "insulation")

def through_inside(p):
    return through_foam(p) or (all_left(p) and p["role"] == "skin_interior")

def displacement(stage, p):
    r, n = p["role"], p["name"]
    if stage == "frame" and r == "frame_rail": return [0, -235, 0]
    if stage == "skins" and r == "skin_exterior": return [-215, -620, 0]
    if stage == "foam" and r == "insulation": return [0, 360, 0]
    if stage == "lining" and r == "skin_interior": return [215, 600, 0]
    if stage == "trim" and r.startswith("decorative_trim"):
        return [0, -235 if r.endswith("stile") else -345, 0]
    return [0, 0, 0]

def prepare_part(p, cfg, mesh):
    v = np.asarray(p["vertices"], dtype=float)
    shift = np.asarray(displacement(cfg.get("explode"), p), dtype=float)
    v += shift
    angle = cfg.get("angles", {}).get(p["leaf"], 0)
    pivot = mesh["leaves"].get(p["leaf"], {}).get("pivot", [0, 0, 0])
    if angle:
        a = math.radians(angle * mesh["leaves"][p["leaf"]]["opening_sign"])
        c, s = math.cos(a), math.sin(a)
        mat = np.array([[c,-s,0],[s,c,0],[0,0,1]])
        v = (v - pivot) @ mat.T + pivot
    else: mat = np.eye(3)
    rotation = cfg.get("rotation", np.eye(3))
    v = v @ rotation.T
    return dict(part=p, vertices=v, triangles=np.asarray(p["triangles"], dtype=int),
                shift=shift, angle=angle, pivot=pivot, hinge_rotation=mat)

def render(cfg, mesh):
    items = [prepare_part(p, cfg, mesh) for p in mesh["parts"] if cfg["select"](p)]
    camera = unit(cfg.get("camera", (.72, -1.1, 1.55)))
    right = unit(np.cross([0,0,1], camera))
    up = np.cross(camera, right)
    basis = np.array([right, up, camera])
    allv = np.concatenate([p["vertices"] for p in items])
    bounds = allv @ basis.T
    low, high = bounds[:, :2].min(0), bounds[:, :2].max(0)
    iw, ih = W * AA, H * AA
    scale = min((iw - 140*AA)/(high[0]-low[0]), (ih - 135*AA)/(high[1]-low[1]))
    center = (low + high)/2
    def project(points):
        x = np.asarray(points) @ basis.T
        x[:,0] = (x[:,0]-center[0])*scale+iw/2
        x[:,1] = -(x[:,1]-center[1])*scale+ih/2-8*AA
        return x
    depth = np.full((ih,iw), -np.inf, dtype=np.float32)
    rgba = np.zeros((ih,iw,4), dtype=np.uint8)
    light = unit((-.45,-.6,1.7))
    material_index = np.full((ih,iw), -1, dtype=np.int16)
    for part_index, item in enumerate(items):
        p, v, tt = item["part"], item["vertices"], item["triangles"]
        pp = project(v)
        color = COLORS[p["material"]]
        if cfg.get("finished") and p["material"] == "plywood_exterior": color = (238,239,229)
        if cfg.get("primed") and p["material"] == "plywood_exterior": color = (230,232,221)
        if cfg.get("finished") and p["material"] == "trim": color = (247,247,239)
        item["color"] = color
        for tri, wtri in zip(pp[tt], v[tt]):
            xlo=max(0,int(np.floor(tri[:,0].min())));xhi=min(iw-1,int(np.ceil(tri[:,0].max())))
            ylo=max(0,int(np.floor(tri[:,1].min())));yhi=min(ih-1,int(np.ceil(tri[:,1].max())))
            if xlo>xhi or ylo>yhi: continue
            (x1,y1,z1),(x2,y2,z2),(x3,y3,z3)=tri
            den=(y2-y3)*(x1-x3)+(x3-x2)*(y1-y3)
            if abs(den)<1e-10: continue
            yy,xx=np.mgrid[ylo:yhi+1,xlo:xhi+1]
            a=((y2-y3)*(xx+.5-x3)+(x3-x2)*(yy+.5-y3))/den
            b=((y3-y1)*(xx+.5-x3)+(x1-x3)*(yy+.5-y3))/den
            c=1-a-b
            zz=a*z1+b*z2+c*z3
            dr=depth[ylo:yhi+1,xlo:xhi+1]
            mask=(a>=-1e-8)&(b>=-1e-8)&(c>=-1e-8)&(zz>dr)
            if not mask.any(): continue
            dr[mask]=zz[mask]
            n=unit(np.cross(wtri[1]-wtri[0], wtri[2]-wtri[0]))
            brightness=.76+.24*abs(float(np.dot(n,light)))
            if cfg.get("finished") and p["material"] in ("plywood_exterior", "trim", "cover"):
                brightness=.94+.06*abs(float(np.dot(n,light)))
            rgb=np.array(color)*brightness
            rgba[ylo:yhi+1,xlo:xhi+1,:3][mask]=rgb.clip(0,255).astype(np.uint8)
            rgba[ylo:yhi+1,xlo:xhi+1,3][mask]=255
            material_index[ylo:yhi+1,xlo:xhi+1][mask]=part_index
    # Depth-tested sharp edges only: triangulation diagonals are suppressed.
    radius=.55*AA
    kernel=[(dx,dy) for dx in range(-2,3) for dy in range(-2,3) if dx*dx+dy*dy<=radius*radius]
    for item in items:
        edge_color=tuple((np.asarray(item["color"])*.54).astype(np.uint8))+(255,)
        for edge in crease_edges(item["vertices"],item["triangles"]):
            a,b=project(edge)
            n=max(2,int(np.linalg.norm(b[:2]-a[:2])*1.4))
            line=np.linspace(a,b,n)
            px=np.floor(line[:,0]).astype(int);py=np.floor(line[:,1]).astype(int)
            for dx,dy in kernel:
                xx,yy=px+dx,py+dy
                valid=(xx>=0)&(xx<iw)&(yy>=0)&(yy<ih)
                xx,yy,dd=xx[valid],yy[valid],line[valid,2]
                good=dd>=depth[yy,xx]-1.8/scale
                rgba[yy[good],xx[good]]=edge_color
    model=Image.fromarray(rgba,"RGBA")
    shadow_mask=model.getchannel("A").filter(ImageFilter.GaussianBlur(5*AA)).point(lambda x:int(x*.10))
    shadow=Image.new("RGBA",(iw,ih),(32,45,38,0));shadow.putalpha(shadow_mask)
    canvas=Image.new("RGBA",(iw,ih),(0,0,0,0))
    canvas.alpha_composite(shadow,(2*AA,8*AA));canvas.alpha_composite(model)
    canvas=canvas.resize((W,H),Image.Resampling.LANCZOS)
    path=OUT/(cfg["name"]+".png")
    canvas.save(path)
    parts=[]
    for k,item in enumerate(items):
        v=item["vertices"]
        b=(project(v)[:,:2]/AA)
        raw_centroid=np.asarray(item["part"]["vertices"],float).mean(0)
        raw_rotated=raw_centroid@cfg.get("rotation",np.eye(3)).T
        pp=project([raw_rotated])[0,:2]/AA
        moved=project([v.mean(0)])[0,:2]/AA
        vis_y,vis_x=np.where(material_index==k)
        parts.append({"source_component":item["part"]["name"],"part_id":role_id(item["part"]),
            "translation_before_camera_mm":item["shift"].tolist(),"opening_angle_deg":item["angle"],
            "hinge_pivot_mm":item["pivot"],"hinge_rotation_matrix":item["hinge_rotation"].tolist(),
            "projected_bounds_px":[b.min(0).tolist(),b.max(0).tolist()],
            "source_centroid_projected_px":pp.tolist(),"transformed_centroid_projected_px":moved.tolist(),
            "visible_pixel_count_at_render_resolution":int(len(vis_x)),
            "visible_pixel_centroid_px":None if len(vis_x)==0 else [float(vis_x.mean()/AA),float(vis_y.mean()/AA)]})
    # Useful fixed construction points: source canonical model coordinates.
    landmarks={
        "left_bottom_hinge_corner":[-1278.65,11.90625,15],
        "left_top_hinge_corner":[-1278.65,11.90625,2153.65],
        "left_bottom_meeting_corner":[-3,11.90625,15],
        "left_top_meeting_corner":[-3,11.90625,2153.65],
        "left_foam_bottom_center":[-640.825,50.00625,571.8875],
        "left_foam_top_center":[-640.825,50.00625,1596.7625],
        "left_outer_seam_midpoint":[-57.85,0,1084.325],
    }
    landmarks={n:(project([np.asarray(v)@cfg.get("rotation",np.eye(3)).T])[0,:2]/AA).tolist() for n,v in landmarks.items()}
    return {"file":str(path),"name":cfg["name"],"description":cfg["description"],
        "orientation":cfg["orientation"],"image_pixels":[W,H],"background":"transparent with subtle shadow",
        "camera_unit_vector":camera.tolist(),"model_rotation_matrix":cfg.get("rotation",np.eye(3)).tolist(),
        "projection_basis_rows":basis.tolist(),"projection_center_mm":center.tolist(),
        "projection_scale_px_per_mm":scale/AA,"pixel_origin":[W/2,H/2-8],
        "parts":parts,"landmarks_px":landmarks,"alpha_content_bbox_px":canvas.getbbox(),
        "notes":["Exact canonical mesh; only rigid transforms.","No hardware product geometry.",
                 "Views are fitted independently and do not share a drawing scale."]}

CONFIGS=[
    dict(name="stage-01-frame-exploded",select=frame,explode="frame",rotation=WORK_OUT,
         orientation="Leaf lies flat, exterior face up; look from the bottom/meeting side.",
         description="One leaf: two stiles stay in place; three complementary half-lap rails lifted 23.5 cm toward the exterior."),
    dict(name="stage-02-outside-skins",select=through_outside,explode="skins",rotation=WORK_OUT,
         orientation="Leaf lies flat, exterior face up; main plywood and infill move together and retain their real 0.32 cm seam.",
         description="P1 main and P2 infill hover outside the timber frame; translated -21.5 cm X and -62 cm Y for clarity."),
    dict(name="stage-03-inside-frame",select=through_outside,rotation=WORK_IN,
         orientation="Leaf turned over; interior face up. Exterior plywood below the open timber cavities.",
         description="Complete frame with exterior plywood installed and interior cavities empty."),
    dict(name="stage-04-foam",select=through_foam,explode="foam",rotation=WORK_IN,
         orientation="Interior face up; look into the two timber cavities.",
         description="Both I1 inserts translated 36 cm toward the interior, directly above their actual cavities."),
    dict(name="stage-05-inside-lining",select=through_inside,explode="lining",rotation=WORK_IN,
         orientation="Interior face up; installed foam below the thin interior skins.",
         description="P3 main and P4 infill translated +21.5 cm X and +60 cm Y for visibility, preserving their real seam."),
    dict(name="stage-06-outside-trim",select=all_left,explode="trim",rotation=WORK_OUT,primed=True,
         orientation="Leaf turned exterior face up; continuous outer skin below applied trim.",
         description="Two T1 stiles lifted 23.5 cm toward exterior; three T2 rails lifted 34.5 cm toward exterior."),
    dict(name="stage-07-complete",select=is_material,finished=True,camera=(.35,-1,.26),
         orientation="Standing pair, seen from outside at a shallow angle; right leaf is active.",
         description="Complete material assembly with white appearance and center cover; hardware omitted."),
    dict(name="stage-08-right-open",select=lambda p:is_material(p) or p["role"]=="jamb_reference",finished=True,
         camera=(0,-1,.46),angles={LEFT:0,RIGHT:65},
         orientation="Standing pair viewed from outside and above; only the right active leaf has opened.",
         description="Right leaf 65 degrees open; left remains closed. Existing jambs shown as muted reference solids. Hinge axes are illustrative."),
    dict(name="stage-09-both-open",select=lambda p:is_material(p) or p["role"]=="jamb_reference",finished=True,
         camera=(0,-1,.46),angles={LEFT:65,RIGHT:65},
         orientation="Standing pair viewed from outside and above; right opens first, then left.",
         description="Both leaves 65 degrees open. Existing jambs shown as muted reference solids. Hinge axes are illustrative."),
    dict(name="overview-front",select=is_material,finished=True,camera=(0,-1,0),
         orientation="Exact orthographic exterior elevation, looking straight at the closed doors.",
         description="Complete pair elevation, no hardware. Subtle line work distinguishes applied trim from plywood fields."),
]

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    source=json.loads(SOURCE.read_text())
    dim=json.loads(DERIVED.read_text())
    assert source["derived_dimensions"]==dim, "Dimension sources disagree"
    assert abs(np.linalg.det(WORK_OUT)-1)<1e-10 and abs(np.linalg.det(WORK_IN)-1)<1e-10
    entries=[]
    for cfg in CONFIGS:
        entry=render(cfg,source)
        entries.append(entry)
        print(cfg["name"],entry["alpha_content_bbox_px"],flush=True)
    manifest={"canonical_source":str(SOURCE),"source_sha256":hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
              "derived_dimensions_source":str(DERIVED),"units":"Canonical mm; parent manual labels cm",
              "rendering":"Per-pixel opaque depth buffer, physical crease edges, 2x supersampling, orthographic projection.",
              "images":entries}
    (OUT/"assembly-art-metadata.json").write_text(json.dumps(manifest,indent=2)+"\n")
    tw,th=640,440
    sheet=Image.new("RGB",(tw*2,(th+48)*5),(249,248,243))
    draw=ImageDraw.Draw(sheet)
    try: font=ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",20)
    except: font=ImageFont.load_default()
    for i,e in enumerate(entries):
        image=Image.open(e["file"]).resize((tw,th),Image.Resampling.LANCZOS)
        x,y=(i%2)*tw,(i//2)*(th+48)
        sheet.paste(image,(x,y),image)
        draw.text((x+18,y+th+6),e["name"],font=font,fill=(26,55,47))
    sheet.save(OUT/"review-contact-sheet.png")

if __name__=="__main__":main()
