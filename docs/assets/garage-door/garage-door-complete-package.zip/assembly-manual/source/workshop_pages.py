"""Six practical workshop pages, executed in build_manual.py's drawing context."""
WORK=PROJECT/'workshop-details'

def workshop_actions(items,top,x=M,w=CW,gap=10):
    y=top
    for i,s in enumerate(items,1):
        C.setFillColor(TEAL);C.circle(x+8,y-6,8,fill=1,stroke=0)
        text(x+8,y-9,str(i),7.8,True,WHITE,'center')
        y=para(s,x+24,y,w-24,SMALL)-gap
    return y

# 21 — identify and cut narrow pieces
start('Which strip do you cut?', 'Six different pieces have different jobs. Quantities below cover both doors.',section='WORKSHOP DETAILS / 1 OF 6')
table([
    ['ID','Qty','Cut L × W, cm','Stock thickness, in','Job / cuts'],
    ['P2','2','213.865 × 5.325','15/32','Outside infill. Rip width; square ends.'],
    ['P4','2','213.865 × 5.325','1/5','Inside infill. Rip width; square ends.'],
    ['T1','4','213.865 × 7.5','0.236 model','Vertical trim. Cut length; rip if wider.'],
    ['T2','6','112.565 × 7.5','0.236 model','Horizontal trim. Square ends between T1.'],
    ['C1','1','213.865 × 6','0.236 model','RIGHT center cover. Fit final end cuts.'],
    ['C2','1','213.865 × 3','0.118 example*','RIGHT spacer. Fit thickness and ends.'],
],M,705,[30,36,129,111,CW-306],SMALL)
section_label('CUTTING SEQUENCE',M,403)
workshop_actions([
    '<b>Measure before ripping.</b> Infill width = actual leaf width − usable main-sheet width − joint gap. The model gives <b>127.565 − 121.92 − 0.32 = 5.325 cm</b>. Existing strips can be reused if their size, flatness and exterior suitability match.',
    '<b>Support the sheet and the offcut.</b> Clamp a straight guide to a stable work surface. Put the blade kerf on the waste side of the finished-width mark. Keep the narrow strip supported; use the saw’s guarding and narrow-cut method.',
    '<b>Make square end cuts.</b> T2 uses simple <b>90° butt ends</b> between T1; no 45° miters or half-laps. Dry-fit before the final end trim. Cut one test piece, then repeat with a stop or matched marks.',
    '<b>Label each piece.</b> Mark its ID, leaf and face on the back. Sand the cut edge and protect it with the chosen finish system, preserving any areas required bare for a later bond. [4]',
],top=385)
box_note('*C2 follows the gasket’s compressed working gap; 0.118 in is an example. Trim model: 0.236 in, not exactly ¼ in. Verify actual stock and door dimensions before cutting.',top=127,label='STOCK AND FIT')
end('Equipment and stock: imperial. Cut lengths, cut widths and workshop marks: cm.')

# 22 — skins and trim are independent fastening operations
start('Fix the plywood strip first','P2 fills the skin width. T1 is a separate decorative cover over the supported seam.',section='WORKSHOP DETAILS / 2 OF 6')
pic(WORK/'strips/fixing-strips-cross-section-cm.png',M,328,CW,381)
workshop_actions([
    '<b>Hold the 0.32 cm seam with removable spacers.</b> Place P2 at the meeting edge, with the full strip and both seam edges supported by the 3½ in wide stile. Fasten P2 independently before fitting T1.',
    '<b>P2 fixing:</b> use exterior wood screws with heads that retain the plywood, seated flush for the trim. A measured <b>1¼ in</b> screw gives about <b>0.781 in</b> geometric reach into timber. Panel-to-frame spacing/count and bonding must suit the actual structural skin.',
    '<b>P4 inside:</b> the 1/5 in lining also fixes into the stile. A measured <b>1 in</b> screw reaches about <b>0.800 in</b> into timber. A low-profile pan/washer head helps retain a thin liner; test the actual head and do not crush the veneer.',
],top=309)
box_note('Remove the spacers once the strip is held. Leave the panel joint open beneath the trim. Keep any trim adhesive on the infill side; do not make a rigid bridge between the two plywood sheets. [2]',top=125,label='COVER THE SEAM; KEEP ITS MOVEMENT SPACE')
end('P2/P4 screw lengths illustrate reach only. Confirm the structural skin connection separately.')

# 23 — proposed trim screw layout and practical driving method
start('Screw on the decorative trim','Proposed retention for flat exterior plywood trim; modeled stock thickness 0.236 in.',section='WORKSHOP DETAILS / 3 OF 6')
pic(WORK/'strips/decorative-trim-screw-layout-cm.png',M,346,CW,363)
para('<b>Example:</b> GRK FIN/Trim, pack label <b>#8 × 1½ in</b>, T10 drive, appropriate exterior coating or stainless variant for the wood and exposure. Drawing length: <b>1.55 in</b>; geometric reach through 0.23622 in trim + 15/32 in plywood: <b>0.845 in</b>. Measure the purchased screw. [6, 7]',M,330,CW,SMALL)
workshop_actions([
    '<b>Dry-fit and clamp.</b> Mark the hidden stile/rail lines on the skin. Put one screw row on the strip centerline, <b>3.75 cm from its long edge</b>. Offset holes along the height to miss existing skin fasteners.',
    '<b>Test the drilling on matching offcuts.</b> A clearance hole is in the strip; a smaller pilot is in the timber. Choose them for the actual screw and wood. The small trim head is only about <b>0.197 in wide</b>: keep adequate head bearing; do not make a large generic countersink.',
    '<b>Drive gently to flush.</b> Use a low drill clutch; finish slowly. The head must retain the 0.236 in strip without crushing or pulling through it. Fill individual cosmetic recesses with exterior filler, sand and finish. No full-width glue bed is required for this proposal.',
],top=258)
para('<b>Counts for both doors:</b> 4 T1 × 10 + 6 T2 × 6 = <b>76 trim screws</b>; center-cover screws are additional. This proposed pattern holds decorative trim; it is not the frame, skin or hinge fastening schedule.',M,82,CW,TINY)
end('First / last screws: 5 cm from ends. Intermediate spacing: T1 ≈22.65 cm; T2 ≈20.51 cm.')

# 24 — top view of center joint and precise fixing line
start('Fasten the center cover','The center cover and spacer attach to the RIGHT leaf and release with it.',section='WORKSHOP DETAILS / 4 OF 6')
sx=M+30;sc=24.5;yy=501
lw=8.89*sc;gap=.6*sc;le=sx+lw;rs=le+gap
ct=yy+3.81*sc;pt=ct+1.190625*sc;tt=pt+.6*sc;st=tt+.3*sc;ot=st+.6*sc
rect(sx,yy,lw,3.81*sc,WOOD,INK)
rect(rs,yy,lw,3.81*sc,WOOD,INK)
rect(sx,ct,lw,1.190625*sc,PLY,INK)
rect(rs,ct,lw,1.190625*sc,PLY,INK)
rect(le-7.5*sc,pt,7.5*sc,.6*sc,WHITE,INK)
rect(rs,pt,7.5*sc,.6*sc,WHITE,INK)
rect(rs,tt,3*sc,.3*sc,WOOD,INK)
rect(le-2.3*sc,tt,2.2*sc,.3*sc,FOAM,INK)
rect(le-2.4*sc,st,6*sc,.6*sc,WHITE,TEAL)
axis=rs+1.5*sc;tip=ot-5.08*sc
line(axis,ot-2,axis,tip,TEAL,2.3)
for yv in range(round(tip+8),round(ct-4),7):line(axis-3,yv-2,axis+3,yv+2,TEAL,1)
line(axis-5,ot-1,axis+5,ot-1,TEAL,2.7)
arrow(axis,tip+8,axis,tip,TEAL,1.4)
dimension_h(le-2.4*sc,rs+3*sc,688,ot,'C1: 6 cm total width')
text(sx,712,'TOP VIEW • OUTSIDE IS ABOVE',8.5,True,TEAL)
text(sx+lw/2,yy+39,'LEFT timber',10,True,INK,'center')
text(rs+lw/2,yy+39,'RIGHT timber',10,True,INK,'center')
text(sx+lw/2,yy+22,'free overlap + gasket',8.5,col=MUTED,align='center')
text(rs+lw/2,yy+22,'screw enters the stile',8.5,col=MUTED,align='center')
dimension_h(rs,axis,477,yy,'1.5 cm')
para('C1: 0.236 in thick<br/>C2: 0.118 in example<br/>T1: 0.236 in thick<br/>P2: 15/32 in thick',rs+3.6*sc,682,135,TINY)
arrow(rs+3.4*sc,674,axis+4,ot-7,TEAL,1)
para('<b>Cover width:</b> 2.4 cm free LEFT overlap + 0.6 cm center gap + 3 cm RIGHT support. Modeled gasket profile: approximately 0.866 in wide within the overlap. Its compressed gap sets the actual spacer thickness.',M,450,CW,SMALL)
workshop_actions([
    '<b>Close and secure LEFT; align RIGHT.</b> Fit the gasket first and select C2 thickness. Cut the cover and spacer ends to the actual head and bottom seals. Their 213.865 cm reference length may need end trimming.',
    '<b>Mark the fixing row on RIGHT only:</b> <b>1.5 cm inside its meeting edge</b>, centered over the 3 cm spacer. On the cover this is <b>4.5 cm from its left edge</b>. Stagger holes to miss P2/T1 screws.',
    '<b>Example cover fastener:</b> exterior-compatible <b>GRK FIN/Trim #8 × 2 in</b>, drawing length <b>2.00 in</b>. Through the example 1.05930 in stack, geometric timber reach is <b>0.941 in</b>. Test the head and drilling as on page 23. [6, 7]',
    '<b>Example cover count:</b> 10 screws, about 5 cm from fitted ends and evenly spaced at no more than about 25 cm. Keep the cover removable. Open RIGHT first and verify that its free overlap clears LEFT.',
],top=391)
box_note('These are weather-cover fixings. Fit handles, latches and other loaded hardware to suitable framing. No cover screw goes into the center air gap or crosses into LEFT.',top=137,label='KEEP THE TWO LEAVES INDEPENDENT')
end('Section is a fixing schematic. No screw count here rates the door or its hardware.')

# 25 — full frame cutting map
start('Mark every frame notch','Keep sound existing joints. This cut map is for replacement F1 uprights and F2 rails.',section='WORKSHOP DETAILS / 5 OF 6')
pic(WORK/'frame/frame-half-lap-cut-map-cm.png',M,329,CW,381)
table([
    ['Member / face to remove','Notch ranges, cm, from one squared reference end'],
    ['F1 upright / OUTSIDE half','0–8.89; 102.4875–111.3775; 204.975–213.865'],
    ['F2 rail / INSIDE half','0–8.89; 118.675–127.565'],
],M,309,[166,CW-166],SMALL)
workshop_actions([
    '<b>Crosscut blanks square:</b> F1 = <b>213.865 cm</b>, four total; F2 = <b>127.565 cm</b>, six total. Keep the 2×4 laid flat: <b>3½ in face × 1½ in depth</b>. No lengthwise ripping of the frame stock is planned.',
    '<b>Label faces and one reference end.</b> Use the actual mating board to mark each notch width. Set the cut depth to half the actual thickness: <b>1.905 cm</b> for actual 1½ in thick stock. The two members lose opposite halves.',
],top=198)
para('<b>Do not cut F2 to 109.785 cm.</b> That is the clear span between uprights. The full-width rail includes its two end overlaps. Model decimals are layout references, not a promise of site precision.',M,83,CW,TINY)
end('Both completed faces should be flush; combined joint thickness equals the original timber depth.')

# 26 — tool sequence for the half-lap
start('Cut and fit the half-lap','Start with two offcuts of the actual timber. A handsaw and sharp chisel are enough for the trial.',section='WORKSHOP DETAILS / 6 OF 6')
pic(WORK/'frame/frame-half-lap-handsaw-chisel-steps-cm.png',M,328,CW,381)
workshop_actions([
    '<b>Knife the shoulder lines and mark the depth on both edges.</b> Secure the board to a firm bench and support its length. Put the saw on the waste side of the line; a small chiseled starter helps locate the cut. [8]',
    '<b>Saw shoulders, then relief cuts.</b> A center notch has two shoulders; an end lap has one. Stop short of the final depth line so the last thin amount can be pared accurately.',
    '<b>Remove small chips with the chisel.</b> Work from each edge toward the middle, keeping hands behind the cutting edge. Pare the floor flat to the line. Do not lever against the retained half.',
    '<b>Dry-fit the complementary pieces.</b> Faces should be flush, shoulders touching and the joint free of rocking. Pare tight high spots; remake a loose or overcut piece. Clamp the full frame flat and compare both diagonals: reference <b>249.020 cm</b>.',
],top=310)
box_note('Cutting accuracy does not select the structural joint connection. Complete the confirmed bonding, fasteners and racking reinforcement for the actual timber and leaf load before adding skins or hanging.',top=125,label='AFTER THE DRY FIT')
end('Cut depth: 1.905 cm in each mating piece. Timber stock: 1½ in thick. Verify actual stock.')
