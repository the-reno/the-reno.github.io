#!/usr/bin/env python3
"""Illustrated assembly manual, grounded in the existing V4 CAD and cm schedule."""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
from xml.sax.saxutils import escape
import json, math, subprocess, shutil
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader, PdfWriter, Transformation
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent
OUT=ROOT/'output'; QA=ROOT/'qa'
OUT.mkdir(exist_ok=True); QA.mkdir(exist_ok=True)
P=json.loads((PROJECT/'cad/parameters.json').read_text())
D=json.loads((PROJECT/'cad/derived_dimensions.json').read_text())
PART_DATA=json.loads((PROJECT/'parts-cm/parts-data-reviewed.json').read_text())
PARTS={p['id']:p for p in PART_DATA['parts']}
PW,PH=A4
M=34;CW=PW-2*M
INK=colors.HexColor('#223638'); TEAL=colors.HexColor('#245e62')
MUTED=colors.HexColor('#607174'); LINE=colors.HexColor('#cbd4cf')
BG=colors.HexColor('#fafaf5'); PALE=colors.HexColor('#edf3ef')
WOOD=colors.HexColor('#c8a573'); PLY=colors.HexColor('#e1cdab')
FOAM=colors.HexColor('#88b3bc'); WHITE=colors.white
AMBER=colors.HexColor('#956022'); WARM=colors.HexColor('#f7edda')
for name,filename in [('Manual','DejaVuSans.ttf'),('ManualBold','DejaVuSans-Bold.ttf')]:
    pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+filename))
pdfmetrics.registerFontFamily('Manual',normal='Manual',bold='ManualBold',italic='Manual',boldItalic='ManualBold')
BODY=ParagraphStyle('Body',fontName='Manual',fontSize=10.8,leading=15.1,textColor=INK)
SMALL=ParagraphStyle('Small',parent=BODY,fontSize=9.1,leading=12.3)
TINY=ParagraphStyle('Tiny',parent=BODY,fontSize=8.1,leading=10.6)
HEAD=ParagraphStyle('Head',parent=BODY,fontName='ManualBold',textColor=WHITE,fontSize=9,leading=12)
TOTAL=27; PAGE=0; AUDIT=[]; OUTLINE=[]; DETAIL_PLACEMENTS=[]
ART_META={Path(a['file']).name:a for a in json.loads((ROOT/'art/assembly-art-metadata.json').read_text())['images']}
DRAFT=QA/'manual-content.pdf'
C=canvas.Canvas(str(DRAFT),pagesize=A4)
C.setTitle('Garage door - imperial equipment and metric cuts')
C.setAuthor('Rafael - garage door project')

def cm(v,nd=3):
    return str(Decimal(str(v/10)).quantize(Decimal(10)**-nd,rounding=ROUND_HALF_UP)).rstrip('0').rstrip('.')

def num(v,nd=3):
    return str(Decimal(str(v)).quantize(Decimal(10)**-nd,rounding=ROUND_HALF_UP)).rstrip('0').rstrip('.')

def text(x,y,s,size=11,bold=False,col=INK,align='left'):
    C.setFillColor(col);C.setFont('ManualBold' if bold else 'Manual',size)
    getattr(C,{'left':'drawString','right':'drawRightString','center':'drawCentredString'}[align])(x,y,str(s))

def para(s,x,top,w,style=BODY,min_y=45):
    obj=Paragraph(s,style);_,h=obj.wrap(w,2000)
    if top-h<min_y:raise ValueError(f'Page {PAGE}: paragraph overflow: {s[:75]} / {top-h}')
    obj.drawOn(C,x,top-h)
    AUDIT.append({'page':PAGE,'kind':'paragraph','text':s,'box':[x,top-h,w,h]})
    return top-h

def rect(x,y,w,h,fill=WHITE,stroke=None,r=0):
    if fill is not None:C.setFillColor(fill)
    if stroke is not None:C.setStrokeColor(stroke)
    C.setLineWidth(.7)
    if r:C.roundRect(x,y,w,h,r,fill=fill is not None,stroke=stroke is not None)
    else:C.rect(x,y,w,h,fill=fill is not None,stroke=stroke is not None)

def line(x1,y1,x2,y2,col=LINE,width=.8,dash=None):
    C.setStrokeColor(col);C.setLineWidth(width);C.setDash(dash or [])
    C.line(x1,y1,x2,y2);C.setDash([])

def arrow(x1,y1,x2,y2,col=TEAL,width=1.6):
    line(x1,y1,x2,y2,col,width)
    a=math.atan2(y2-y1,x2-x1);L=7
    pts=[(x2,y2),(x2-L*math.cos(a-.4),y2-L*math.sin(a-.4)),(x2-L*math.cos(a+.4),y2-L*math.sin(a+.4))]
    p=C.beginPath();p.moveTo(*pts[0]);p.lineTo(*pts[1]);p.lineTo(*pts[2]);p.close()
    C.setFillColor(col);C.drawPath(p,fill=1,stroke=0)

def section_label(s,x=M,y=700):text(x,y,s,10,True,TEAL)

def box_note(s,x=M,top=165,w=CW,tone='green',label='CHECK BEFORE CONTINUING'):
    st=ParagraphStyle('note',parent=SMALL,textColor=INK)
    ob=Paragraph(s,st);_,h=ob.wrap(w-26,1000)
    hh=h+42
    rect(x,top-hh,w,hh,WARM if tone=='amber' else PALE,None,6)
    text(x+13,top-17,label,8.8,True,AMBER if tone=='amber' else TEAL)
    para(s,x+13,top-27,w-26,st)
    return top-hh

def pic(path,x,y,w,h):
    path=Path(path)
    if not path.exists():raise FileNotFoundError(path)
    with Image.open(path)as im:iw,ih=im.size
    k=min(w/iw,h/ih);dw=iw*k;dh=ih*k
    xx=x+(w-dw)/2;yy=y+(h-dh)/2
    if (path.parent==ROOT/'details' or 'workshop-details' in path.parts) and path.with_suffix('.pdf').exists():
        DETAIL_PLACEMENTS.append({'page':PAGE,'path':str(path.with_suffix('.pdf')),'box':[xx,yy,dw,dh]})
    else:
        C.drawImage(str(path),xx,yy,dw,dh,mask='auto')
    AUDIT.append({'page':PAGE,'kind':'image','path':str(path),'box':[xx,yy,dw,dh]})
    return xx,yy,dw,dh

def art(name,x=M,y=370,w=CW,h=325,labels=False):
    box=pic(ROOT/'art'/name,x,y,w,h)
    if not labels:return box
    xx,yy,dw,dh=box;meta=ART_META[name];seen=set()
    allowed={
        'stage-01-frame-exploded.png':{'F1','F2'},
        'stage-02-outside-skins.png':{'P1','P2','F1','F2'},
        'stage-04-foam.png':{'I1'},
        'stage-05-inside-lining.png':{'P3','P4'},
        'stage-06-outside-trim.png':{'T1','T2'},
    }.get(name,set())
    for part in meta['parts']:
        ident=part.get('part_id')
        if ident in seen or ident not in allowed:continue
        p=part.get('visible_pixel_centroid_px')
        if not p:continue
        seen.add(ident);px=xx+p[0]/1600*dw;py=yy+dh-p[1]/1100*dh
        # Small tags identify the actual CAD component; leader starts outside its face.
        shift=-48 if ident in ('F1','P1','I1','T1') else 48
        tx=min(PW-M-22,max(M+22,px+shift));ty=py+22
        line(tx,ty-5,px,py,TEAL,.8)
        rect(tx-15,ty-6,30,18,TEAL,None,4);text(tx,ty-1,ident,8.8,True,WHITE,'center')
    # Assembly arrows connect each lifted part to its actual unshifted CAD location.
    for part in meta['parts']:
        a=part.get('transformed_centroid_projected_px');b=part.get('source_centroid_projected_px')
        if a and b and math.dist(a,b)>20:
            ax=xx+a[0]/1600*dw;ay=yy+dh-a[1]/1100*dh
            bx=xx+b[0]/1600*dw;by=yy+dh-b[1]/1100*dh
            arrow(ax,ay,bx,by,TEAL,1.1)
    return box

def badge(s,x,y):
    tw=pdfmetrics.stringWidth(s,'ManualBold',9)+18
    rect(x,y-6,tw,22,PALE,None,5);text(x+9,y+1,s,9,True,TEAL)
    return tw

def chips(items,top=690):
    x=M
    for item in items:
        width=pdfmetrics.stringWidth(item,'ManualBold',9)+18
        if x+width>PW-M:raise ValueError(f'chip row too long on {PAGE}')
        badge(item,x,top);x+=width+7

def actions(items,top=334,x=M,w=CW,gap=12):
    y=top
    for i,s in enumerate(items,1):
        C.setFillColor(TEAL);C.circle(x+9,y-7,9,fill=1,stroke=0)
        text(x+9,y-10,str(i),8,True,WHITE,'center')
        end=para(s,x+27,y,w-27)
        y=end-gap
    return y

def check(s,x,top,w=CW,style=SMALL):
    rect(x,top-10,9,9,None,TEAL)
    return para(s,x+19,top,w-19,style)-9

def table(rows,x,top,widths,style=SMALL):
    cells=[[Paragraph(str(v),HEAD if r==0 else style)for v in row]for r,row in enumerate(rows)]
    t=Table(cells,colWidths=widths)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),TEAL),('ROWBACKGROUNDS',(0,1),(-1,-1),[WHITE,PALE]),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,1),(-1,-1),.4,LINE)]))
    _,h=t.wrap(sum(widths),2000)
    if top-h<47:raise ValueError(f'table overflow page{PAGE}')
    t.drawOn(C,x,top-h);AUDIT.append({'page':PAGE,'kind':'table','box':[x,top-h,sum(widths),h]})
    return top-h

def start(title,sub='',step=None,section='ASSEMBLY MANUAL'):
    global PAGE
    PAGE+=1;rect(0,0,PW,PH,BG)
    text(M,814,'GARAGE DOOR  /  '+section,9,True,MUTED)
    text(PW-M,814,f'{PAGE:02d} / {TOTAL}',9,True,MUTED,'right')
    if step:
        rect(M,754,45,41,TEAL,None,6);text(M+22.5,767,step,18,True,WHITE,'center')
        tx=M+58;tw=CW-58;fs=25
    else:tx=M;tw=CW;fs=29
    while pdfmetrics.stringWidth(title,'ManualBold',fs)>tw:fs-=.25
    text(tx,765,title,fs,True)
    if sub:para(sub,M,741,CW,SMALL,min_y=710)
    OUTLINE.append({'title':('Step '+step+' - ' if step else '')+title,'page':PAGE})

def end(note='Equipment / stock: imperial. Cuts / workshop layout: cm. Verify before cutting.'):
    line(M,35,PW-M,35)
    text(M,22,note,7.5,col=MUTED)
    text(PW-M,22,f'{PAGE:02d}',8,True,MUTED,'right')
    C.showPage()

def leaf_drawing(x,y,s,trim=True,inside=False):
    w=D['leaf_width_mm']/10*s;h=D['leaf_height_mm']/10*s
    f=P['frame_face_width_mm']/10*s;t=P['trim_face_width_mm']/10*s
    rect(x,y,w,h,PLY,INK)
    if inside:
        for sx in [x,x+w-f]:rect(sx,y,f,h,WOOD,INK)
        for z in D['rail_lower_edges_from_leaf_bottom_mm']:
            rect(x,y+z/10*s,w,f,WOOD,INK)
    elif trim:
        for sx in [x,x+w-t]:rect(sx,y,t,h,WHITE,LINE)
        for z in D['trim_rail_lower_edges_from_leaf_bottom_mm']:
            rect(x+t,y+z/10*s,w-2*t,t,WHITE,LINE)
    return w,h

def dimension_h(x1,x2,y,origin,label):
    line(x1,origin,x1,y+4);line(x2,origin,x2,y+4);line(x1,y,x2,y,TEAL)
    for xx in (x1,x2):line(xx-2.5,y-3,xx+2.5,y+3,TEAL)
    ww=pdfmetrics.stringWidth(label,'ManualBold',9)+9
    rect((x1+x2-ww)/2,y-5,ww,15,BG,None)
    text((x1+x2)/2,y-1,label,9,True,TEAL,'center')

def dimension_v(y1,y2,x,origin,label):
    line(origin,y1,x+4,y1);line(origin,y2,x+4,y2);line(x,y1,x,y2,TEAL)
    for yy in(y1,y2):line(x-3,yy-2.5,x+3,yy+2.5,TEAL)
    C.saveState();C.translate(x-5,(y1+y2)/2);C.rotate(90)
    ww=pdfmetrics.stringWidth(label,'ManualBold',9)+9;rect(-ww/2,-5,ww,15,BG,None);text(0,-1,label,9,True,TEAL,'center');C.restoreState()

def opening_diagram(x,y,s,labels=True):
    ow=P['opening_width_mm']/10*s;oh=P['opening_height_mm']/10*s
    rect(x-9,y,ow+18,oh+10,PALE,LINE);rect(x,y,ow,oh,BG,INK)
    lw=D['leaf_width_mm']/10*s;gap=P['center_gap_mm']/10*s
    side=P['hinge_side_gap_mm']/10*s;bot=P['bottom_gap_mm']/10*s
    leaf_drawing(x+side,y+bot,s);leaf_drawing(x+side+lw+gap,y+bot,s)
    if labels:
        text(x+side+lw/2,y+oh*.7,'LEFT',11,True,TEAL,'center')
        text(x+side+lw/2,y+oh*.64,'closes first',8.5,col=MUTED,align='center')
        text(x+side+lw+gap+lw/2,y+oh*.7,'RIGHT',11,True,TEAL,'center')
        text(x+side+lw+gap+lw/2,y+oh*.64,'opens first',8.5,col=MUTED,align='center')
    return ow,oh

# 01 - cover
start('Garage door assembly','An illustrated guide for rebuilding your existing outward-opening pair.',section='V4 / FIELD-FIT EDITION')
art('stage-07-complete.png',M,355,CW,350)
text(M,329,'SELECT MATERIALS IN IMPERIAL; CUT IN cm',10,True,TEAL)
table([['Outside plywood','Flat timber core','Inside plywood','White trim'],['15/32 in thick','2×4; actual 1½ × 3½ in','1/5 in thick','Model: 0.236 in thick']],M,315,[CW/4]*4)
para('Use imperial labels for tools, fasteners and stock. Cuts and workshop marks are in cm. Keep sound existing framing; replacement half-laps apply only where needed.',M,230,CW)
table([['Find the next action','Pages'],['Measure, gather tools and identify parts','2-5'],['Prepare frame, backing, plywood and insulation','6-13'],['Fit trim, finish, hang and seal','14-19'],['Record checks; workshop details; source notes','20-27']],M,183,[CW-55,55],TINY)
end('Planning basis: 257 × 216 cm opening. The site and hardware must be verified.')

# 02 - work preparation and field record
start('Before you cut','Record the existing door sizes and opening. All sizes in this manual remain field-fit references.')
ow,oh=opening_diagram(66,485,0.86)
dimension_h(66,66+ow,465,485,'257 cm opening reference')
dimension_v(485,485+oh,48,66,'216 cm reference')
x=326
section_label('MEASURE AND WRITE',x,700)
y=682
for label in ['Opening widths: top / middle / bottom','Opening heights: left / center / right','Both opening diagonals','Existing LEFT: width / height / depth','Existing RIGHT: width / height / depth','Floor high point through the full swing']:
    y=para(label,x,y,PW-M-x,TINY)-17;line(x,y+4,PW-M,y+4)
section_label('TOOLS AND WORKSPACE',M,432)
para('Tape measure, square, straightedge/level, pencil, clamps, flat supports, drill/driver and bits. A guided saw for plywood; suitable joint-cutting tools only for replacement frame members. Add sanding/finishing supplies, eye/hearing/dust protection, and a helper with suitable lifting/support equipment.',M,416,CW,SMALL)
section_label('CONFIRM THESE BEFORE ASSEMBLY',M,344)
y=325
for s in [
    '<b>Material condition:</b> dry, flat timber and sound joints. Record existing braces before opening the leaf; keep sound reinforcement.',
    '<b>Products:</b> verify the outside plywood is suitable for permanent exterior use; select the foam and its required protective covering. The 1/5 in liner has no established fire/thermal-barrier rating. [1]',
    '<b>Hardware:</b> obtain the actual hinge, latch and bolt templates, including fastener requirements and access to any nuts or backing plates.',
    '<b>Bonding and finish:</b> choose compatible products before priming. Coatings on a glue surface may prevent the required bond. [3, 4]']:
    y=check(s,M,y)
box_note('If the measured opening, retained frame or required covering differs, revise the cut sizes and weight calculation together. Equal leaves are an assumption in this model.',top=121,label='DIMENSION RULE',tone='amber')
end()

# 03-05 - placeholders replaced with the original vector parts catalog.
for label in ['Parts - frame and plywood','Parts - insulation, trim and center joint','Parts - hardware and seals']:
    start(label,'Illustrated parts reference; quantities cover both doors.',section='PARTS')
    end()

# 06 - open retained leaf
start('Open and label the existing leaf','Work on one leaf at a time. This drawing shows the reference frame, not an inspection of your existing door.',step='01')
chips(['LEFT / RIGHT', 'OUTSIDE / INSIDE', 'TOP / BOTTOM'])
art('stage-03-inside-frame.png',M,365,CW,315)
actions([
    '<b>Support the leaf securely before releasing its hinges.</b> Mark its handing, top, hinge edge and outside face. Photograph hinge positions and measure the original gaps.',
    'Lower it onto flat, padded supports. Remove the skins carefully enough to preserve sound framing, joints and braces.',
    'Inspect for decay, splits, loose joints, twist and loose fixings. Mark the members that actually need repair; keep the others.'],top=344)
box_note('You have recorded the actual frame layout and hardware locations. The leaf is supported flat, and every proposed repair is identified.',top=126)
end()

# 07 - square frame
start('Repair and square the frame','For each reference leaf: two uprights and three full-width cross rails. Replacement cuts are conditional.',step='02')
chips(['F1 × 2 per door', 'F2 × 3 per door', 'Keep sound existing joints'])
art('stage-01-frame-exploded.png',M,386,CW,300,labels=True)
actions([
    'Lay out the retained or replacement members on a flat bench. For new reference members, use the complementary half-laps on the next page.',
    f'Clamp to <b>{cm(D["leaf_width_mm"])} cm wide × {cm(D["leaf_height_mm"])} cm high</b>. Compare both diagonals and adjust the frame until it is square and flat.',
    'Complete the confirmed joint fastening/bonding arrangement. Keep the frame square while it sets; retain or provide the required racking reinforcement.'],top=362)
box_note('Nominal rectangle diagonal: 249.020 cm in both directions. Geometry alone does not define joint strength: confirm the joint fixings and racking resistance for the actual timber and leaf load. [5]',top=147,tone='amber',label='FRAME CHECK')
end()

# 08 - half-lap detail
start('Half-lap cuts for replacements','Use this page only when rebuilding frame members. Cut half the actual timber thickness, not blindly to a nominal value.',step='02A')
pic(ROOT/'details/detail-01-half-lap-assembly-cm.png',M,430,CW,276)
section_label('F1: NOTCH LOWER EDGES FROM THE LEAF BOTTOM',M,405)
nx=66;ny=327;ns=2.0
rect(nx,ny,D['leaf_height_mm']/10*ns,P['frame_face_width_mm']/10*ns,WOOD,INK)
for z in D['rail_lower_edges_from_leaf_bottom_mm']:
    px=nx+z/10*ns
    rect(px,ny+P['frame_face_width_mm']/10*ns/2,P['frame_face_width_mm']/10*ns,P['frame_face_width_mm']/10*ns/2,PALE,TEAL)
    text(px,374,cm(z,4)+' cm',9,True,TEAL,'center');arrow(px,366,px,348,TEAL,1)
text(nx,313,'BOTTOM',8,True,MUTED)
text(nx+D['leaf_height_mm']/10*ns,313,'TOP',8,True,MUTED,'right')
dimension_h(nx,nx+D['leaf_height_mm']/10*ns,291,ny,'213.865 cm full upright length')
para('<b>Cut orientation:</b> remove the outside half of F1 at the crossings and the inside half of F2 at its ends. Each notch is <b>8.89 cm long × 1.905 cm deep</b> in actual 1½ in thick timber.',M,264,CW,SMALL)
para('<b>Fit:</b> trial-fit one lap before repeating cuts. Broad mating faces meet fully, both door faces finish flush, and the total frame depth remains <b>1½ in</b>.',M,211,CW,SMALL)
box_note('The F2 rail blank is the full 127.565 cm leaf width. Its ends overlap the uprights; do not shorten it to the 109.785 cm clear space between them.',top=132,label='CUTTING CHECK')
end('Replacement-only geometry. Select joint fastening for the actual wood and load.')

# 09 - backing schematic and product choices
start('Prepare hardware backing','Select the actual hardware first. Every loaded fixing needs sound wood behind it.',step='03')
chips(['H1 hinges', 'H3 latch', 'H4 bolts', 'Backing: field-sized'])
rect(M,431,CW,254,WHITE,LINE,5)
# Enlarged generic strap fixing detail: schematic, deliberately not a drilling template.
sx=M+34;sy=503
rect(sx,sy,52,142,WOOD,INK)
rect(sx+52,sy+43,254,67,WOOD,INK)
rect(sx+52,sy,254,43,FOAM,LINE)
rect(sx+52,sy+110,254,32,FOAM,LINE)
rect(sx+17,sy+60,289,27,INK,None,2)
for xx in [sx+32,sx+108,sx+197,sx+284]:
    C.setFillColor(WHITE);C.circle(xx,sy+73.5,4.5,fill=1,stroke=0)
text(sx,666,'SCHEMATIC: hardware pattern governs the backing',9,True,TEAL)
arrow(sx+330,sy+139,sx+223,sy+111)
para('Full-depth backing<br/>within the 1½ in core',sx+318,sy+165,139,TINY)
arrow(sx+320,sy+22,sx+198,sy+62)
para('Every loaded fixing<br/>engages sound timber',sx+318,sy+29,144,TINY)
text(sx,450,'No hole positions or extra-blocking cut sizes are specified by this sketch.',8.3,col=MUTED)
actions([
    'Place the real hinge, latch and bolt templates on the frame. Mark the hole centers, edge clearances and jamb/keeper locations.',
    'Align the hardware with suitable rails/stiles or add securely connected full-depth blocking to its exact pattern. Update the foam cuts and weight allowance.',
    'Complete access-dependent fasteners, nuts or backing plates before closing the skins. Record the selected fixings on page 20.'],top=411)
box_note('All load paths reach solid door framing and a sound structural jamb. Thin plywood and foam are not the hinge anchorage. The illustration adds example backing; it is not part of the base cut count.',top=158,label='BEFORE COVERING THE FRAME')
end('Hardware holes, fastener sizes and blocking joints follow the selected system.')

# 10 - exterior skins
start('Attach the outside plywood','Keep the frame flat and square. Mirror the two leaves so their narrow strips meet at the center.',step='04')
chips(['P1 × 1 per door', 'P2 × 1 per door', 'Outside face up'])
art('stage-02-outside-skins.png',M,381,CW,300,labels=True)
actions([
    f'Dry-fit <b>P1: {cm(D["leaf_height_mm"])} × 121.92 cm</b> and the matching <b>P2 strip: {cm(D["leaf_height_mm"])} × 5.325 cm</b>. Use 15/32 in outside plywood.',
    'Put the narrow strip at the meeting edge. Keep the reference <b>0.32 cm seam</b> between the pieces, with timber beneath both edges; see the next page. [2]',
    'Mark the timber lines on the face. Attach the skins with the confirmed wood/substrate bonding and fastening schedule; keep fixings over timber and recheck square.'],top=359)
box_note('Measure the usable sheet width first. Infill width = measured leaf width - usable main-panel width - selected seam. Protect cut edges, while keeping glue surfaces compatible with the chosen adhesive.',top=136,label='BEFORE THE FINAL RIP CUT')
end()

# 11 - supported seam
start('Keep the seam supported','The narrow strip makes up the extra door width. The white meeting trim hides the seam after assembly.',step='04A')
pic(ROOT/'details/detail-03-plywood-seam-cm.png',M,369,CW,338)
actions([
    'Keep the seam over the meeting stile <b>at the location shown</b>. At the model sizes, the main sheet bears on <b>3.245 cm</b> of timber and the strip bears on <b>5.325 cm</b>.',
    'Preserve the <b>0.32 cm</b> movement seam. Avoid rigid wood filler or a continuous rigid glue bridge across it. Follow the chosen panel and weather-detail instructions. [2]',
    'Later, fix the <b>7.5 cm</b> meeting trim through the strip side into the stile. Its opposite edge covers the main sheet while allowing the joint to move.'],top=346)
box_note('Apply the same supported-seam layout to P3/P4 on the inside. The shown exterior trim is the seam cover; the thin interior lining has no added cover strip in the base part list.',top=139,label='REPEAT ON THE INSIDE')
end()

# 12 - insulation
start('Fit the insulation inside','Turn only after the outer-skin bonding system permits handling. Set the exterior face down on padded, flat supports.',step='05')
chips(['I1 × 2 per door', 'Inside face up', '1½ in core'])
art('stage-04-foam.png',M,382,CW,306,labels=True)
actions([
    'Measure the actual cavities after repairs and hardware backing. Cut each unblocked reference insert to <b>109.485 × 93.298 cm</b> from <b>1½ in</b> foam; two per leaf.',
    'Cut and trial-fit each insert without forcing it. Allow for adhesive bedding so the foam finishes flush with, or below, the frame plane and cannot bow the inner skin.',
    'Use adhesive approved for the exact foam/facing and substrates. Follow its application, retention and full-cure instructions; keep the assembly supported flat. [3]'],top=360)
box_note('A straightedge across the frame does not rock on proud foam. Hardware fixings remain accessible as required. Verify the selected foam covering requirements before fitting the 1/5 in lining.',top=151,label='BEFORE CLOSING THE INSIDE')
end()

# 13 - inner plywood
start('Close the inside face','Use the thinner sheet as an interior lining. Keep the narrow strip on the meeting stile.',step='06')
chips(['P3 × 1 per door', 'P4 × 1 per door', '1/5 in lining'])
art('stage-05-inside-lining.png',M,388,CW,300,labels=True)
actions([
    f'Dry-fit <b>P3: {cm(D["leaf_height_mm"])} × 121.92 cm</b> and <b>P4: {cm(D["leaf_height_mm"])} × 5.325 cm</b>. Preserve the supported seam just as on the outside.',
    'Transfer the rail, stile and backing lines to the lining. Attach using the confirmed fixing schedule into wood; seat the heads without crushing or pulling through the thin sheet.',
    'Support flat for the required adhesive cure. Check the diagonal, face flatness, exposed edges and all hardware access before proceeding.'],top=365)
box_note('The lining does not become a structural hinge backing, nor a verified protective covering for every foam product, merely because it covers the cavity. Use the selected material instructions.',top=145,label='LINING CHECK')
end()

# 14 - applied trim
start('Fit the white decorative trim','Dry-fit the pieces on the outside faces of both leaves. Use the same horizontal reference line across the pair.',step='07')
chips(['T1 × 2 per door', 'T2 × 3 per door', 'Cut 7.5 cm wide; stock 0.236 in'])
art('stage-06-outside-trim.png',M,390,CW,300,labels=True)
actions([
    'Place the two full-height <b>T1 verticals</b> at the outside edges of each leaf. Fit the three <b>112.565 cm T2 rails</b> between them.',
    'Reference rail lower edges are <b>0, 103.1825 and 206.365 cm</b> above the leaf bottom. The middle trim center is <b>106.9325 cm</b>. Keep the two doors visually aligned.',
    'Use the proposed decorative fixing layout on <b>page 23</b>: 10 screws per T1, 6 per T2, into timber. The meeting-seam section is on page 22. Ease exposed edges and protect cut ends.'],top=368)
box_note('The trim is cut 7.5 cm wide; the hidden 2×4 frame has a 3½ in face. Their middle centerlines agree; their lower-edge measurements differ. Do not use the trim marks to cut frame notches.',top=142,label='ALIGNMENT CHECK')
end()

# 15 - finishing
start('Seal and finish all exposed wood','Protect the door before installation, and reseal any later cuts or drilled preparations.',step='08')
art('stage-07-complete.png',M,412,CW,276)
# Diagrammatic edge/face instruction band.
for i,lab in enumerate(['OUTSIDE','INSIDE','TOP + BOTTOM','HINGE + MEETING EDGES']):
    xx=M+i*(CW+8)/4;ww=(CW-24)/4
    rect(xx,366,ww,34,PALE,None,4);text(xx+ww/2,380,lab,7.7,True,TEAL,'center')
actions([
    'Sand and remove dust. Ease sharp exposed edges enough for coating coverage, without changing joint bearing or the intended fit.',
    'Follow the selected exterior finish system. Cover both faces, all four edges, trim ends and cut plywood edges. Preserve any intentionally bare bonding areas until their adhesive operation is complete. [4]',
    'Let the coating cure as directed. After fitting hardware or trimming the center cover, reseal the new holes/cuts and touch up disturbed areas.'],top=344)
box_note('Check the top and bottom edges with the leaf still on supports. Those edges are easy to miss after hanging. Coating counts and cure times come from the selected product, not this drawing.',top=147,label='FINISH CHECK')
end()

# 16 - hang
start('Weigh, check hinges, then hang','Complete the hardware suitability check before a trial hang. Use a helper and secure lifting/support equipment.',step='09')
ow,oh=opening_diagram(143,427,1.2)
dimension_h(143,143+ow,408,427,'257 cm opening reference')
text(M,394,'TOP / SIDES  0.635 cm',9,True,TEAL)
text(PW-M,394,'CENTER  0.6 cm   |   BOTTOM  1.5 cm',9,True,TEAL,'right')
actions([
    'Record each leaf\'s actual weight with all fitted parts; include the measured weight of anything still to be added. Confirm the hinge system, joint connections, fasteners and jamb for the actual width, weight and exposure.',
    'Set the <b>left leaf</b> on secure temporary supports, then the right. Use the measured gaps and actual hinge template. Keep hinge axes aligned and the leaves level with one another.',
    'Fasten to the selected specification while keeping the leaf supported. Test the full outward swing over the highest floor point before removing temporary supports.'],top=370)
box_note('The drawn gaps are starting allowances. Actual hinge geometry, trim depth, floor slope and weatherseal compression control the fit. Do not use the model\'s ideal hinge pivot as a drilling template.',top=142,label='FIT CHECK')
end('Hinge quantities on the parts page are planning counts, not load ratings.')

# 17 - center overlap
start('Fit the center cover and seal','The right leaf is active. The cover, spacer and gasket move with it.',step='10')
chips(['C1 cover × 1', 'C2 spacer × 1', 'S1 gasket × 1', 'RIGHT ONLY'])
pic(ROOT/'details/detail-04-center-cover-cm.png',M,388,CW,294)
actions([
    'Hold the left leaf closed and secure it. With both leaves aligned, confirm the center gap and dry-fit the cover across it: <b>3 cm support on the right + 0.6 cm gap + 2.4 cm overlap on the left</b>.',
    'Select the real gasket, then set C2 to its required compressed working gap. The drawing\'s <b>0.118 in spacer and compressed gasket</b> are examples, not the seal\'s uncompressed purchase thickness.',
    'Cut cover, spacer and seal ends to the fitted head/bottom details. Fix C1/C2 into the <b>right meeting timber only</b>. Fit S1 under the left overlap so it compresses against the left leaf.'],top=365)
box_note('The cover releases when the right leaf opens. No screw or rigid glue joint crosses into the left leaf. Check even compression and easy latch action along the full height.',top=125,label='CENTER-JOINT CHECK')
end()

# 18 - hardware / seals
start('Fit the latch, bolts and seals','Use the selected hardware and weatherseal templates. Fit each seal to the actual installed gap.',step='11')
# Exterior elevation schematic with legend; no drilling dimensions.
s=.99;x=74;y=446
ow,oh=opening_diagram(x,y,s,labels=False)
lw=D['leaf_width_mm']/10*s;lh=D['leaf_height_mm']/10*s
side=P['hinge_side_gap_mm']/10*s;bgap=P['bottom_gap_mm']/10*s
for yy in [y+bgap+14,y+bgap+lh-22]:
    rect(x+side+lw-14,yy,6,17,INK,None)
rect(x+side+lw+6,y+bgap+lh/2,29,8,INK,None)
line(x,y+oh+3,x+ow,y+oh+3,TEAL,3)
line(x-3,y,x-3,y+oh,TEAL,3);line(x+ow+3,y,x+ow+3,y+oh,TEAL,3)
line(x+side,y+bgap,x+side+lw,y+bgap,TEAL,3)
line(x+side+lw+P['center_gap_mm']/10*s,y+bgap,x+ow-side,y+bgap,TEAL,3)
section_label('FIT TO SOUND BACKING',352,692)
para('<b>LEFT</b><br/>Two bolts: top and bottom.<br/><br/><b>RIGHT</b><br/>Active latch and center cover.<br/><br/><b>BOTH</b><br/>Pulls and hold-open devices.<br/><br/><b>PERIMETER</b><br/>Head + two sides + two bottoms.',352,674,208,SMALL)
text(M,424,'Schematic positions only; use the manufacturer\'s mounting templates.',8.5,col=MUTED)
actions([
    'Install the two left-leaf bolts and their keepers into suitable door framing and supports. Fit the right-leaf latch, pulls and both hold-open devices.',
    'Fit the head and jamb seals to sound stops. Fit the two bottom seals to the actual threshold/floor condition without using them to support door weight.',
    'Join the center seal to the head/bottom weather details. Check for continuous contact, free movement, water-shedding edges and no trapped lower-edge water.'],top=403)
box_note('Reference runs: head 257 cm; sides 2 × 216 cm; bottoms 2 × 127.565 cm. These are measuring allowances. Different locations may need different profiles; final cut lengths follow the installed detail.',top=159,label='SEAL LENGTHS')
end()

# 19 - operation
start('Test the opening sequence','Operate slowly first. Support and adjust any leaf that rubs, drops or loads the latch.',step='12')
rect(M,398,(CW-14)/2,295,WHITE,LINE,5)
rect(M+(CW+14)/2,398,(CW-14)/2,295,WHITE,LINE,5)
text(M+13,670,'1  OPEN RIGHT FIRST',10,True,TEAL)
text(M+(CW+14)/2+13,670,'2  RELEASE / OPEN LEFT',10,True,TEAL)
art('stage-08-right-open.png',M+8,422,(CW-14)/2-16,232)
art('stage-09-both-open.png',M+(CW+14)/2+8,422,(CW-14)/2-16,232)
para('<b>OPEN:</b> unlatch and open the right leaf; release the left bolts; open the left. Secure both with their hold-open devices.',M,377,CW)
para('<b>CLOSE:</b> close the left leaf and secure its bolts first. Close and latch the right leaf over the center gasket last.',M,324,CW)
y=267
for s in ['Both leaves swing fully without rubbing the floor, jamb, post or one another.','All hinges and anchors remain firm; the latch closes without lifting the door.','The cover releases freely, the gasket contacts evenly, and the seals do not bind.','Finish is complete on edges, ends and later hardware cuts.']:
    y=check(s,M,y)
box_note('Recheck after initial use and seasonal weather changes. Investigate sag, loose fasteners, damaged finish or deteriorated seals before they worsen.',top=119,label='AFTER ASSEMBLY')
end('Opening poses use the CAD\'s illustrative axes; verify the actual installation.')

# 20 - actual records / fastening geometry (no invented schedule)
start('Complete the assembly record','Use this page with the actual hardware instructions. The manual does not invent a structural screw schedule.')
table([['Record','LEFT leaf','RIGHT leaf'],['Finished width / height, cm','________________','________________'],['Actual final weight, lb','________________','________________'],['Hinge model / number','________________','________________'],['Fastener specification / embedment, in','________________','________________'],['Jamb material / sound anchorage','________________','________________']],M,705,[CW-244,122,122])
section_label('FASTENER REACH: CHECK THE MATERIAL STACK',M,463)
para('The values below are the layers crossed <b>before</b> the screw reaches timber. Add the selected fastener\'s required timber embedment, then check that its tip and head suit the actual assembly. These are geometry checks, not selected screw lengths.',M,447,CW,SMALL)
table([['Fixing location','Layers before timber, inches'],['Outside skin','15/32 = 0.46875'],['Inside lining','1/5 = 0.200'],['White trim through outside skin','0.23622 + 0.46875 ≈ 0.70497'],['Center cover, example spacer, trim and skin','0.23622 + 0.11811 + 0.23622 + 0.46875 ≈ 1.05930'],['Hinge or other hardware','Actual hardware + actual intervening layers']],M,385,[251,CW-251],TINY)
y=188
for s in ['Frame joints / reinforcement confirmed; access-dependent fixings completed.','Actual hinge, latch, bolt and hold-open instructions kept with the project.','Both opening directions and all seal transitions checked; later cuts resealed.']:
    y=check(s,M,y)
end('Record selected product details; a count or screw length alone does not establish capacity.')

# 21-26 - detailed workshop instructions added at the user's request
exec((ROOT/'source/workshop_pages.py').read_text(), globals())

# 27 - source support and scope
start('Design notes and references','The drawings show the current V4 geometry and your stated material thicknesses. Product instructions control product-specific assembly.')
section_label('DESIGN BASIS AND USE',M,704)
para('Reference opening: <b>257 × 216 cm</b>; leaf cuts: <b>127.565 × 213.865 cm</b>. Stock: 15/32 in outside plywood, 1½ in core, 1/5 in lining; trim model 0.236 in. Use imperial for purchases and cm for cuts/marks. Quantities cover both leaves. Verify actual stock and site dimensions.',M,686,CW,SMALL)
para('Keep sound existing framing. Pages 21–26 add workshop methods and a proposed decorative-trim fixing layout. They do not establish structural, wind, fire or thermal performance. Verify actual frame connections, panel bracing, hardware and foam covering for the installation.',M,617,CW,SMALL)
refs=[
('1','APA — Plywood exposure classifications','https://www.apawood.org/engineered-wood-products/plywood-osb/plywood/','Verify the exterior-use marking; thickness alone does not define exposure suitability.'),
('2','APA — Prevent Buckling with Proper Spacing','https://www.apawood.org/guides-tools-training/technical-document-library/builder-tips/prevent-buckling-with-proper-spacing/','General panel spacing guidance; the supported 0.32 cm seam is this project’s detail.'),
('3','Henkel — LOCTITE PL 300 technical data','https://datasheets.tdx.henkel.com/LOCTITE-PL-300-Foamboard-Construction-Adhesive-en_US.pdf','Check exact foam, facing, substrate, retention and cure; no sandwich-panel rating is implied.'),
('4','Simpson Door Company — Care and finishing','https://www.simpsondoor.com/care-finishing/','Protect faces, edges and later cuts using the selected coating system.'),
('5','Titebond III — Manufacturer limitations','https://www.titebond.com/print/product/e8d40b45-0ab3-49f7-8a9c-b53970f736af','Exterior-use glue is not a structural door-joint specification; stated limitations apply.'),
('6','GRK — Finish Trim Head product','https://www.grkfasteners.com/grk-products/finish/finish-trim-head-screw','Exterior-trim application, finishes, T10 drive and pack labels. Our spacing/counts are a proposal.'),
('7','GRK — Finish screw drawing, dated 11/01/2023','https://www.grkfasteners.com/getmedia/f67facbb-a893-4636-a420-d057ced4480d/GRK-Finish-Customer-Drawing_3.pdf?ext=.pdf','Nominal #8 × 1½ in product: drawing L = 1.55 in; #8 × 2 in product: L = 2.00 in. Measure purchased parts.'),
('8','Lee Valley Tools — Mastering Handsaw Cuts','https://www.leevalley.com/en-gb/discover/woodworking/2020/august/mastering-handsaw-cuts','Christopher Schwarz: knife-marked shoulders, waste-side saw starts and securely clamped work.')]
y=548
for n,title,url,scope in refs:
    y=para(f'<b>[{n}] {escape(title)}</b> — {escape(scope)}',M,y,CW,TINY)
    y=para(f'<link href="{escape(url)}" color="#245e62">Open primary reference</link>',M,y-2,CW,TINY)-9
para('Unit convention updated 09 October 2026. CAD geometry and workshop illustrations are original. Retain the exact cm cut list and 3D model with this manual. Screw reach is geometric penetration, including the tip; it is not a load-capacity calculation.',M,y-1,CW,TINY)
end('Assembly edition / V4. Revise the model, cut list and manual together if dimensions change.')

assert PAGE==TOTAL,(PAGE,TOTAL)
C.save()

# Integrate the existing vector parts boards without retyping or resampling their dimensions.
overlay=QA/'parts-page-overlays.pdf'
OC=canvas.Canvas(str(overlay),pagesize=A4)
for page_no in (3,4,5):
    OC.setFillColor(BG);OC.rect(PW-73,805,53,25,fill=1,stroke=0)
    OC.setFillColor(MUTED);OC.setFont('ManualBold',9)
    OC.drawRightString(PW-24,815,f'{page_no:02d} / {TOTAL}')
    OC.setFont('Manual',6.6);OC.drawString(24,7,'ASSEMBLY MANUAL / PARTS REFERENCE / QUANTITIES FOR BOTH DOORS')
    OC.drawRightString(PW-24,7,f'{page_no:02d}');OC.showPage()
OC.save()
source=PdfReader(str(DRAFT));catalog=PdfReader(str(PROJECT/'parts-cm/deliverables/garage-door-parts-centimeters.pdf'));ov=PdfReader(str(overlay))
writer=PdfWriter()
for i,page in enumerate(source.pages):
    if i in (2,3,4):
        page=catalog.pages[i-2];page.merge_page(ov.pages[i-2])
    for detail in DETAIL_PLACEMENTS:
        if detail['page']==i+1:
            dp=PdfReader(detail['path']).pages[0]
            xx,yy,dw,dh=detail['box'];sw=float(dp.mediabox.width);sh=float(dp.mediabox.height)
            assert abs(dw/dh-sw/sh)<0.01
            page.merge_transformed_page(dp,Transformation().scale(dw/sw,dh/sh).translate(xx,yy))
    writer.add_page(page)
writer.add_metadata({'/Title':'Garage door - imperial equipment and metric cuts','/Author':'Rafael - garage door project','/Subject':'V4 field-fit assembly guide with measured parts and construction details'})
for item in OUTLINE:writer.add_outline_item(item['title'],item['page']-1)
FINAL=OUT/'garage-door-assembly-manual-cm.pdf'
with FINAL.open('wb')as f:writer.write(f)

# Render each page independently and verify the image stream before delivery.
rendered=[]
for pnum in range(1,TOTAL+1):
    base=QA/f'page-{pnum:02d}'
    path=base.with_suffix('.png')
    for attempt in range(3):
        subprocess.run(['pdftoppm','-r','140','-f',str(pnum),'-l',str(pnum),'-singlefile','-png',str(FINAL),str(base)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            with Image.open(path)as im:im.load()
            with Image.open(path)as im:im.verify()
            break
        except OSError:
            if attempt==2:raise
    rendered.append(str(path))

(ROOT/'layout-audit.json').write_text(json.dumps({'page_count':TOTAL,'units':{'equipment_and_stock':'imperial','cuts_and_layout':'cm'},'outline':OUTLINE,'blocks':AUDIT,'details':DETAIL_PLACEMENTS,'rendered_pages':rendered,'source_parameters':P,'source_parts_count':PART_DATA['scheduled_piece_count']},indent=2))
print(json.dumps({'pdf':str(FINAL),'page_count':TOTAL,'rendered_pages':len(rendered)},indent=2))
