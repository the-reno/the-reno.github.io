#!/usr/bin/env python3
"""One-page visual index of the assembly manual, using the same CAD stage images."""
from pathlib import Path
import subprocess
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from PIL import Image

R=Path(__file__).resolve().parents[1]
BG=colors.HexColor('#fafaf5');INK=colors.HexColor('#223638');TEAL=colors.HexColor('#245e62');MUTED=colors.HexColor('#607174');LINE=colors.HexColor('#cbd4cf')
for name,f in [('OV','DejaVuSans.ttf'),('OVB','DejaVuSans-Bold.ttf')]:pdfmetrics.registerFont(TTFont(name,'/usr/share/fonts/truetype/dejavu/'+f))
pdfmetrics.registerFontFamily('OV',normal='OV',bold='OVB')
style=ParagraphStyle('s',fontName='OV',fontSize=9.4,leading=12.4,textColor=INK)
pw,ph=A4;pdf=R/'qa/assembly-overview.pdf';c=canvas.Canvas(str(pdf),pagesize=A4)
c.setFillColor(BG);c.rect(0,0,pw,ph,fill=1,stroke=0)
def t(x,y,s,sz=10,bold=False,col=INK):
 c.setFillColor(col);c.setFont('OVB' if bold else 'OV',sz);c.drawString(x,y,s)
t(27,812,'GARAGE DOOR / VISUAL ASSEMBLY GUIDE',9.5,True,MUTED)
t(27,773,'Assembly at a glance',27,True)
t(27,746,'Six phases. The printable manual gives all 12 numbered steps.',10,col=MUTED)
cards=[
('1. Frame and backing','Manual steps 01-03','stage-01-frame-exploded.png','Retain sound 2x4 members (actual 1-1/2 x 3-1/2 in). Add hardware backing before the skins.'),
('2. Outside plywood','Manual step 04 + seam detail','stage-02-outside-skins.png','P1 + P2: 15/32 in plywood. Keep the narrow strip and supported seam at the meeting edge.'),
('3. Insulation','Manual step 05','stage-04-foam.png','I1: two 1-1/2 in inserts per door. Fit flush in the core after adhesive bedding.'),
('4. Inside lining','Manual step 06','stage-05-inside-lining.png','P3 + P4: 1/5 in plywood. Fix to the timber and keep the lining flat.'),
('5. Trim and finish','Manual steps 07-08','stage-06-outside-trim.png','T1 + T2: cut 7.5 cm wide; model thickness approx. 0.236 in. Align across the pair; finish all faces.'),
('6. Hang, seal and test','Manual steps 09-12','stage-08-right-open.png','Weigh and verify hardware first. Center cover: RIGHT only. Right opens first; left closes first.')]
for i,(title,step,name,note)in enumerate(cards):
 col=i%2;row=i//2;x=27+col*278;top=721-row*216;w=263;h=202
 c.setFillColor(colors.white);c.setStrokeColor(LINE);c.setLineWidth(.7);c.roundRect(x,top-h,w,h,5,fill=1,stroke=1)
 fs=12.5
 while pdfmetrics.stringWidth(title,'OVB',fs)>w-22:fs-=.2
 t(x+11,top-22,title,fs,True,TEAL);t(x+11,top-37,step,8.3,col=MUTED)
 image=R/'art'/name
 with Image.open(image)as im:iw,ih=im.size
 scale=min((w-18)/iw,111/ih);dw=iw*scale;dh=ih*scale
 c.drawImage(str(image),x+(w-dw)/2,top-150+(111-dh)/2,dw,dh,mask='auto')
 p=Paragraph(note,style);_,hh=p.wrap(w-22,1000)
 assert hh<=38
 p.drawOn(c,x+11,top-159-hh)
note=Paragraph('Equipment, hardware and stock sizes use imperial units; cuts and marking use cm. Check the actual opening and stock before cutting. Lifted-part spacing is illustrative; hardware and finish follow the selected products.',ParagraphStyle('f',parent=style,fontSize=8.1,leading=10.8,textColor=MUTED))
_,hh=note.wrap(pw-54,1000);note.drawOn(c,27,52-hh)
c.save()
target=R/'output/garage-door-assembly-overview-cm'
for attempt in range(3):
 subprocess.run(['pdftoppm','-r','220','-singlefile','-png',str(pdf),str(target)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
 try:
  with Image.open(target.with_suffix('.png'))as im:im.load()
  with Image.open(target.with_suffix('.png'))as im:im.verify()
  break
 except OSError:
  if attempt==2:raise
print(target.with_suffix('.png'))
