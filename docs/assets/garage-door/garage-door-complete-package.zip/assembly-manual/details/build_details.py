#!/usr/bin/env python3
"""Measured SVG construction details for the current V4 garage door.

Run from any working directory. Geometry is read from the canonical V4 JSON,
cutting and marking dimensions are converted from millimeters to centimeters;
stock, hardware and equipment use imperial labels. Inkscape renders SVG to PNG
and PDF. No image generation or artificial geometry is used.
"""
from pathlib import Path
import json
import math
import subprocess
from html import escape
from PIL import Image, ImageOps, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
P = json.loads((ROOT / 'cad/parameters.json').read_text())
D = json.loads((ROOT / 'cad/derived_dimensions.json').read_text())
M = json.loads((ROOT / 'cad/preview_mesh.json').read_text())

W, H = 1600, 850
C = dict(bg='#ffffff', ink='#15343d', muted='#57717b', line='#c5d4d8',
         teal='#0d7278', blue='#dceef1', wood='#debd8b', wood2='#f3d7ae',
         ply='#ecdfc4', trim='#f7f9fa', seal='#354650', red='#a54837')

def cm(v):
    return v / 10

def f(v, places=4):
    s = f'{v:.{places}f}'.rstrip('0').rstrip('.')
    return s if s else '0'

class SVG:
    def __init__(self, title, subtitle):
        self.p = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
                  '<defs>',
                  '<marker id="arrow" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 Z" fill="#57717b"/></marker>',
                  '<marker id="action" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M 0 0 L 10 5 L 0 10 Z" fill="#0d7278"/></marker>',
                  '<pattern id="hatch" width="16" height="16" patternUnits="userSpaceOnUse"><rect width="16" height="16" fill="#debd8b"/><path d="M-4 4L4-4M0 16L16 0M12 20L20 12" stroke="#b99261" stroke-width="1" opacity=".40"/></pattern>',
                  '<pattern id="notch" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill="#dceef1"/><path d="M-3 3L3-3M0 12L12 0M9 15L15 9" stroke="#0d7278" stroke-width="1.2" opacity=".75"/></pattern>',
                  '</defs>',
                  f'<rect width="{W}" height="{H}" fill="{C["bg"]}"/>']
        self.text(54, 62, title, 38, bold=True)
        self.text(54, 99, subtitle, 22, color='muted')
        self.line(54, 122, 1546, 122, color='line')

    def text(self, x, y, text, size=23, bold=False, color='ink', anchor='start', rotate=None):
        color = C.get(color, color)
        rot = f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ''
        self.p.append(f'<text x="{x:.3f}" y="{y:.3f}" font-family="DejaVu Sans, sans-serif" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}" text-anchor="{anchor}"{rot}>{escape(text)}</text>')

    def lines(self, x, y, lines, size=23, leading=31, **kw):
        for i, t in enumerate(lines):
            self.text(x, y + i*leading, t, size=size, **kw)

    def line(self,x1,y1,x2,y2,color='ink',width=2,dash=None,arrow=None):
        attrs = f' stroke-dasharray="{dash}"' if dash else ''
        if arrow == 'both': attrs += ' marker-start="url(#arrow)" marker-end="url(#arrow)"'
        if arrow == 'action': attrs += ' marker-end="url(#action)"'
        self.p.append(f'<line x1="{x1:.3f}" y1="{y1:.3f}" x2="{x2:.3f}" y2="{y2:.3f}" stroke="{C.get(color,color)}" stroke-width="{width}"{attrs}/>')

    def poly(self, pts, fill='wood2', stroke='ink', width=2, dash=None):
        pts = ' '.join(f'{x:.3f},{y:.3f}' for x,y in pts)
        dd = f' stroke-dasharray="{dash}"' if dash else ''
        self.p.append(f'<polygon points="{pts}" fill="{C.get(fill,fill)}" stroke="{C.get(stroke,stroke)}" stroke-width="{width}"{dd}/>')

    def rect(self,x,y,w,h,fill='wood',stroke='ink',width=2,dash=None,rx=0):
        dd=f' stroke-dasharray="{dash}"' if dash else ''
        self.p.append(f'<rect x="{x:.3f}" y="{y:.3f}" width="{w:.3f}" height="{h:.3f}" rx="{rx}" fill="{C.get(fill,fill)}" stroke="{C.get(stroke,stroke)}" stroke-width="{width}"{dd}/>')

    def circle(self,x,y,r=4,fill='teal'):
        self.p.append(f'<circle cx="{x:.3f}" cy="{y:.3f}" r="{r}" fill="{C.get(fill,fill)}"/>')

    def dim_h(self,x1,x2,y,origin_y,label,label_dy=-13,size=22):
        self.line(x1,origin_y,x1,y+7,'line',1.5)
        self.line(x2,origin_y,x2,y+7,'line',1.5)
        self.line(x1,y,x2,y,'muted',1.4,arrow='both')
        self.text((x1+x2)/2,y+label_dy,label,size,color='muted',anchor='middle')

    def dim_v(self,y1,y2,x,origin_x,label,size=22):
        self.line(origin_x,y1,x+6,y1,'line',1.5)
        self.line(origin_x,y2,x+6,y2,'line',1.5)
        self.line(x,y1,x,y2,'muted',1.4,arrow='both')
        self.text(x-15,(y1+y2)/2,label,size,color='muted',anchor='middle',rotate=-90)

    def leader(self,pts,label=None,x=None,y=None,size=22):
        for (x1,y1),(x2,y2) in zip(pts[:-1],pts[1:]): self.line(x1,y1,x2,y2,'muted',1.6)
        self.circle(*pts[0],r=3)
        if label:
            self.text(x if x is not None else pts[-1][0],y if y is not None else pts[-1][1]-10,label,size,color='muted')

    def footer(self, extra=''):
        self.line(54,790,1546,790,'line',1.5)
        self.text(54,822,'Stock: imperial  •  Cuts / marks: cm  •  V4 model reference  •  Not full size',18,color='muted')
        if extra: self.text(1546,822,extra,18,color='muted',anchor='end')

    def save(self,name):
        self.p.append('</svg>')
        path=HERE/f'{name}.svg'
        path.write_text('\n'.join(self.p))
        for ext in ['png','pdf']:
            subprocess.run(['inkscape',str(path),f'--export-type={ext}',f'--export-filename={HERE/f"{name}.{ext}"}'],check=True,capture_output=True,text=True)
        with Image.open(HERE/f'{name}.png') as im: im.verify()
        return path


def half_lap():
    s=SVG('HALF-LAP: FIT THE RAIL INTO THE STILE',
          'Replacement members only. Keep sound existing frame joints.')
    lap=D['half_lap_length_mm']; t=P['core_depth_mm']; half=D['half_lap_depth_mm']
    scale=2.1
    def rail(x,y,length=220):
        pts=[(0,0),(length,0),(length,t),(lap,t),(lap,half),(0,half)]
        s.poly([(x+a*scale,y+b*scale) for a,b in pts],fill='wood2')
    s.text(75,174,'1  BRING THE MATCHING CUTS TOGETHER',24,bold=True,color='teal')
    x,y=105,286
    rail(x,y)
    stile_y=473
    s.rect(x,stile_y,lap*scale,half*scale,'url(#hatch)')
    s.line(x,y+half*scale,x,stile_y,'line',2,'7 6')
    s.line(x+lap*scale,y+half*scale,x+lap*scale,stile_y,'line',2,'7 6')
    s.line(x+lap*scale/2,385,x+lap*scale/2,448,'teal',4,arrow='action')
    s.text(x+lap*scale+28,499,'F1 stile: remaining half',23)
    s.text(x+lap*scale+30,260,'F2 rail end',23,bold=True)
    s.dim_h(x,x+lap*scale,567,stile_y+half*scale,f'{cm(lap):.2f} cm overlap')
    s.dim_v(y,y+t*scale,x+220*scale+63,x+220*scale,'1-1/2 in stock')
    s.leader([(x+lap*scale/2,y+half*scale/2),(x+10,218),(80,218)])
    s.text(80,205,'1.905 cm remaining',22,color='muted')

    s.line(760,180,760,635,'line',1.5)
    s.text(835,174,'2  BOTH FACES FINISH FLUSH',24,bold=True,color='teal')
    x2,y2=870,355
    rail(x2,y2)
    s.rect(x2,y2+half*scale,lap*scale,half*scale,'url(#hatch)')
    s.line(x2-25,y2,x2+485,y2,'teal',1.5,'7 6')
    s.line(x2-25,y2+t*scale,x2+485,y2+t*scale,'teal',1.5,'7 6')
    s.text(x2,307,'OUTSIDE FACE',21,bold=True,color='teal')
    s.text(x2,479,'INSIDE FACE',21,bold=True,color='teal')
    s.dim_v(y2,y2+t*scale,x2+220*scale+64,x2+220*scale,'1-1/2 in total')
    s.dim_h(x2,x2+lap*scale,547,y2+t*scale,'8.89 cm overlap')
    s.text(x2+18,601,'1.905 cm + 1.905 cm = 1-1/2 in',22,color='muted')

    s.rect(54,665,1492,101,'blue','none',rx=12)
    s.text(79,699,'F2 full rail blank: 127.565 cm long.',25,bold=True)
    s.text(79,735,'Cut complementary laps to half the actual timber thickness; dry-fit flat before fixing.',23)
    s.text(1518,735,'Section through joint',19,color='muted',anchor='end')
    s.footer()
    return s.save('detail-01-half-lap-assembly-cm')


def notch_layout():
    s=SVG('STILE: MARK THE THREE NOTCHES',
          'Mark in cm from the bottom of the leaf. Stock: nominal 2x4, actual 1-1/2 x 3-1/2 in.')
    ht=cm(D['leaf_height_mm']); fw=cm(P['frame_face_width_mm'])
    scale=2.45; x=247; bot=722; top=bot-ht*scale
    s.text(72,170,'F1 • 4 STILES FOR BOTH DOORS',24,bold=True,color='teal')
    s.rect(x,top,fw*scale,ht*scale,'wood2')
    s.dim_v(top,bot,151,x,'213.865 cm full length')
    starts=[cm(v) for v in D['rail_lower_edges_from_leaf_bottom_mm']]
    for i,v in enumerate(starts):
        y=bot-v*scale
        s.rect(x,y-fw*scale,fw*scale,fw*scale,'url(#notch)',width=1.8)
        s.line(x+fw*scale,y,630,y,'muted',1.5,'6 5')
        if i == 0:
            s.text(300,y-17,'0 cm - bottom notch begins',23,bold=True)
        else:
            s.text(300,y-15,f'{f(v)} cm - notch lower edge',23,bold=True)
    s.leader([(x+fw*scale,top+118),(366,top+88),(634,top+88)])
    s.text(380,top+75,'3-1/2 in stock face',22,color='muted')
    s.text(300,750,'Copy these marks to the other stiles.',20,color='muted')

    s.line(735,168,735,752,'line',1.5)
    s.text(805,170,'EACH NOTCH: SIDE SECTION',24,bold=True,color='teal')
    # Local side profile: z along the upright, depth into the timber to the right.
    q=15.0; xx=960; yy=287; t=cm(P['core_depth_mm']); half=t/2; nl=fw
    hh=24.0
    pts=[(0,0),(t,0),(t,hh),(0,hh),(0,16.5),(half,16.5),(half,16.5-nl),(0,16.5-nl)]
    s.poly([(xx+a*q,yy+b*q) for a,b in pts],fill='wood2')
    cut_y=yy+(16.5-nl)*q
    s.rect(xx,cut_y,half*q,nl*q,'none','teal',1.5,'7 5')
    s.dim_v(cut_y,cut_y+nl*q,xx-63,xx,'8.89 cm notch length')
    s.dim_h(xx,xx+half*q,cut_y-49,cut_y,'1.905 cm deep',size=21)
    s.dim_h(xx,xx+t*q,yy+hh*q+42,yy+hh*q,'1-1/2 in stock',size=21)
    s.leader([(xx+half*q*0.5,cut_y+nl*q*.55),(1100,420),(1460,420)])
    s.lines(1122,371,['Remove this half.', 'Keep the other half.'],size=23)
    s.lines(1116,506,['Nominal depth: 1.905 cm.', 'Use half the measured', 'thickness of your timber.'],size=23)
    s.text(805,747,'Side-section ends are cropped; the full length is shown at left.',20,color='muted')
    s.footer()
    return s.save('detail-02-stile-notch-layout-cm')


def plywood_seam():
    s=SVG('PLYWOOD: SUPPORT THE SEAM ON TIMBER',
          'Representative left meeting stile shown. Mirror this detail for the right door.')
    q=55.0;x=220;y=407
    fw=cm(P['frame_face_width_mm']); depth=cm(P['core_depth_mm']); ply=cm(P['exterior_skin_thickness_mm'])
    main,gap,infill=[cm(v) for v in D['meeting_stile_seam_support_chain_mm']]
    trim=cm(P['trim_face_width_mm']); tt=cm(P['trim_thickness_mm']); trim_start=fw-trim
    # Actual rectangular section at a position clear of the horizontal rail joints.
    s.rect(x,y,fw*q,depth*q,'url(#hatch)')
    py=y-ply*q
    s.rect(x-98,py,98+main*q,ply*q,'ply')
    s.rect(x+(main+gap)*q,py,infill*q,ply*q,'wood2')
    ty=py-tt*q
    s.rect(x+trim_start*q,ty,trim*q,tt*q,'trim')
    s.text(x+fw*q/2,y+depth*q*.55,'F1 • SOLID MEETING STILE',21,bold=True,anchor='middle')
    # Small, explicit break at the end of the continuing main panel.
    for yy in [py+10,py+30,py+50]: s.line(x-104,yy,x-92,yy+11,'muted',2)
    s.text(76,464,'Main panel',20,color='muted')
    s.text(76,491,'continues',20,color='muted')
    s.dim_h(x+trim_start*q,x+fw*q,266,ty,'7.5 cm trim cut width')
    s.dim_h(x+trim_start*q,x+main*q,207,ty,'1.855 cm overlap on main',size=20)
    s.dim_h(x,x+main*q,676,y+depth*q,'3.245 cm bearing',size=20)
    s.dim_h(x+(main+gap)*q,x+fw*q,676,y+depth*q,'5.325 cm infill',size=20)
    s.dim_h(x,x+fw*q,738,y+depth*q,'3-1/2 in solid timber face')
    s.leader([(x+(main+gap/2)*q,py+ply*q*.5),(803,377),(907,377)])
    s.lines(923,363,['0.32 cm movement seam', 'Keep the gap open.'],size=22)
    # Arrow describes load path, without inventing a screw size or depth schedule.
    fixx=x+6.4*q
    s.line(fixx,ty-13,fixx,y+1.30*q,'teal',4,arrow='action')
    s.leader([(fixx,y+.7*q),(817,490),(887,490)])

    s.text(950,175,'THE OUTSIDE LAYERS',24,bold=True,color='teal')
    for yy,color,code,desc in [
        (211,'trim','T1','Trim: approx. 0.236 in thick'),
        (250,'ply','P1','Main plywood: 15/32 in thick'),
        (289,'wood2','P2','Matching 15/32 in infill')]:
        s.rect(950,yy,24,24,color,width=1.5)
        s.text(990,yy+21,f'{code}  {desc}',21)
    s.lines(923,464,['Fix trim through the infill side', 'into the solid timber.'],size=25,bold=True)
    s.lines(923,559,['Do not rigidly glue the trim', 'across both edges of the seam.'],size=25,bold=True,color='red')
    s.lines(923,658,['Recalculate infill width from the actual', 'usable width of your main plywood sheet.'],size=22,color='muted')
    s.line(120,269,120,204,'teal',3,arrow='action')
    s.text(120,186,'OUTSIDE',18,bold=True,color='teal',anchor='middle')
    s.footer('Top section')
    return s.save('detail-03-plywood-seam-cm')


def center_cover():
    s=SVG('CENTER CONNECTION: THE COVER BELONGS TO THE RIGHT DOOR',
          'Top section through the closed doors. Spacer and gasket thicknesses are working-gap examples.')
    sx=800;sy=390;q=5.0
    colors={'plywood_exterior':'ply','plywood_interior':'ply','timber':'url(#hatch)',
            'foam':'blue','trim':'trim','spacer':'wood2','cover':'trim','gasket_reference':'seal'}
    selected=[]
    for part in M['parts']:
        b=part['bounds_mm']; mat=part['material']
        if mat not in colors or not b['zmin']<315<b['zmax']: continue
        lo=max(-105,b['xmin']);hi=min(105,b['xmax'])
        if hi<=lo:continue
        s.rect(sx+lo*q,sy+b['ymin']*q,(hi-lo)*q,(b['ymax']-b['ymin'])*q,colors[mat],width=1.6)
        selected.append(part['name'])
    s.text(497,520,'LEFT • INACTIVE',23,bold=True,anchor='middle')
    s.text(1103,520,'RIGHT • ACTIVE',23,bold=True,anchor='middle')
    s.text(800,742,'INSIDE / GARAGE',21,bold=True,color='teal',anchor='middle')
    # Actual cover width, overlap and right-side support.
    s.dim_h(sx-27*q,sx+33*q,189,sy-15*q,'6 cm cover cut width',size=22)
    s.dim_h(sx-27*q,sx-3*q,257,sy-9*q,'2.4 cm overlap',size=20)
    s.dim_h(sx+3*q,sx+33*q,257,sy-9*q,'3 cm support',size=20)
    # Clearly separate the section leader callouts.
    s.leader([(sx-15*q,sy-7.5*q),(510,289),(88,289)])
    s.lines(88,188,['S1 • GASKET (MODEL)', 'Width: approx. 0.866 in', 'Compressed: approx. 0.118 in', 'Inset: 0.1 cm at each end of overlap'],size=21,leading=27)
    s.leader([(sx+20*q,sy-7.5*q),(1107,310),(1465,310)])
    s.lines(1140,239,['C2 • SPACER', 'Cut width: 3 cm', 'Approx. 0.118 in thick'],size=21,leading=27)
    s.leader([(sx+29*q,sy-12*q),(1105,219),(1465,219)])
    s.lines(1140,153,['C1 • COVER', 'Cut width: 6 cm', 'Approx. 0.236 in thick'],size=21,leading=27)
    # The 0.6 cm leaf gap is drawn to scale; leader avoids an unreadable short dim line.
    s.line(sx-3*q,696,sx+3*q,696,'muted',1.4,arrow='both')
    s.line(sx-3*q,sy+55.08625*q,sx-3*q,703,'line',1.5)
    s.line(sx+3*q,sy+55.08625*q,sx+3*q,703,'line',1.5)
    s.leader([(sx,696),(969,716),(1450,716)])
    s.text(1030,700,'0.6 cm gap between leaves',22,color='muted')
    s.text(80,576,'OUTSIDE',21,bold=True,color='teal')
    s.line(135,554,135,453,'teal',3,arrow='action')
    s.lines(80,746,['C1, C2 and the gasket move with the RIGHT leaf.'],size=21,bold=True)
    s.footer('Right opens first. Left closes first.')
    return s.save('detail-04-center-cover-cm'),selected


def main():
    assert math.isclose(D['half_lap_depth_mm']*2,P['core_depth_mm'])
    assert math.isclose(sum(D['meeting_stile_seam_support_chain_mm']),P['frame_face_width_mm'])
    assert math.isclose(D['center_cover_left_overlap_mm']+P['center_gap_mm']+D['center_cover_right_support_mm'],P['center_cover_width_mm'])
    assert math.isclose(P['gasket_compressed_width_mm']+2*D['gasket_inset_within_left_overlap_mm'],D['center_cover_left_overlap_mm'])
    assert D['rail_lower_edges_from_leaf_bottom_mm'] == [0,1024.875,2049.75]
    paths=[half_lap(),notch_layout(),plywood_seam()]
    cp,selected=center_cover();paths.append(cp)
    tiles=[]
    for p in paths:
        with Image.open(p.with_suffix('.png')) as im:
            tiles.append(ImageOps.contain(im.convert('RGB'),(800,425)))
    contact=Image.new('RGB',(1600,850),'#dde4e5')
    for i,im in enumerate(tiles):contact.paste(im,((i%2)*800,(i//2)*425))
    contact.save(HERE/'detail-contact-sheet.png')
    audit={'source':'V4 canonical parameters, derived dimensions and preview_mesh.json',
           'units':'imperial stock and equipment; centimeters for cuts and marking',
           'dimension_conversion':'canonical mm / 10 for cuts and marks; canonical mm / 25.4 for stock thickness',
           'status':'provisional construction reference; site size and actual timber must be measured',
           'checks':{'half_lap_complement':True,'seam_bearing_chain':True,'cover_span_chain':True,'gasket_inset_chain':True,'stile_notch_starts':True},
           'center_section_cut_z_mm':315,'center_section_clipped_x_mm':[-105,105],
           'center_section_parts':selected,'outputs':[p.name for p in paths],
           'notes':['No discrepancy found between requested dimensions and canonical V4 model.',
                    'Hardware fixing size and count are not supplied by these diagrams.',
                    'Gasket and spacer thickness are examples pending selection of the seal profile.',
                    'Trim and spacer model thicknesses are approximately 0.236 and 0.118 in; they are not exact 1/4 and 1/8 in stock.',
                    'Actual main plywood sheet width governs infill width.',
                    'Half-lap detail shows a section through the joint; upright and rail are orthogonal in plan.']}
    (HERE/'detail-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
    print(json.dumps({'outputs':[str(p) for p in paths],'contact_sheet':str(HERE/'detail-contact-sheet.png')},indent=2))

if __name__=='__main__':main()
