from pathlib import Path
from html import escape
import json
import fitz
from decimal import Decimal, ROUND_HALF_UP

ROOT = Path(__file__).resolve().parent
W, H = 1800, 1300
C = dict(bg='#f3f1e9', ink='#153f43', sub='#426165', wood='#dfbd88', edge='#a7814d', light='#f0d6ad', waste='#e98b6a', red='#b94f35', blue='#bad9df', blueedge='#648e96', rule='#bbc8c5')

class SVG:
    def __init__(self):
        self.a=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">', '<defs><pattern id="hatch" width="14" height="14" patternUnits="userSpaceOnUse"><path d="M-4 4L4-4M0 14L14 0M10 18L18 10" stroke="#a7432b" stroke-width="2"/></pattern></defs>']
        self.rect(0,0,W,H,C['bg'])
    def rect(self,x,y,w,h,fill='none',stroke='none',sw=1,rx=0): self.a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    def line(self,x1,y1,x2,y2,stroke=None,sw=2,dash=None): self.a.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke or C["ink"]}" stroke-width="{sw}"'+(f' stroke-dasharray="{dash}"' if dash else '')+'/>')
    def poly(self,pts,fill,stroke=None,sw=2): self.a.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in pts)+f'" fill="{fill}" stroke="{stroke or C["ink"]}" stroke-width="{sw}" stroke-linejoin="round"/>')
    def text(self,x,y,s,size=25,fill=None,weight='normal',anchor='start'):
        self.a.append(f'<text x="{x}" y="{y}" fill="{fill or C["ink"]}" font-family="Arial, sans-serif" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}">{escape(str(s))}</text>')
    def lines(self,x,y,lines,size=25,leading=33,fill=None,weight='normal'):
        for n,s in enumerate(lines): self.text(x,y+n*leading,s,size,fill,weight)
    def arrow(self,x1,y1,x2,y2,stroke=None,sw=3):
        import math
        self.line(x1,y1,x2,y2,stroke,sw)
        a=math.atan2(y2-y1,x2-x1); k=11
        self.poly([(x2,y2),(x2-k*math.cos(a-.43),y2-k*math.sin(a-.43)),(x2-k*math.cos(a+.43),y2-k*math.sin(a+.43))],stroke or C['ink'],stroke or C['ink'],1)
    def dim(self,x1,x2,y,label,size=23):
        self.line(x1,y,x2,y,C['sub'],1.5)
        for x in (x1,x2): self.line(x,y-8,x,y+8,C['sub'],1.5)
        self.text((x1+x2)/2,y-10,label,size,C['sub'],anchor='middle')
    def header(self,kicker,title,sub):
        self.rect(0,0,W,145,C['ink'])
        self.text(45,37,kicker,21,'#d2e5df',weight='bold')
        self.text(45,88,title,43,'#ffffff',weight='bold')
        self.text(45,123,sub,24,'#e1ece8')
    def card(self,x,y,w,h): self.rect(x,y,w,h,'#ffffff',C['rule'],1.3,16)
    def save(self,stem):
        self.a.append('</svg>')
        svg=ROOT/(stem+'.svg'); svg.write_text('\n'.join(self.a))
        source=fitz.open('svg',svg.read_bytes()); pdf=fitz.open('pdf',source.convert_to_pdf())
        pdf.set_metadata({'title':stem.replace('-',' '),'author':'Garage door project — workshop detail'})
        pdf.save(ROOT/(stem+'.pdf'))
        pdf[0].get_pixmap(matrix=fitz.Matrix(1,1),alpha=False).save(ROOT/(stem+'.png'))
        return pdf[0].get_text()

def waste(s,x,y,w,h):
    s.rect(x,y,w,h,C['waste'],C['red'],1.5)
    # Explicit segments render consistently in SVG-to-PDF engines without pattern support.
    for offset in range(-int(h),int(w)+14,14):
        xx1=max(0,offset); xx2=min(w,offset+h)
        if xx1 < xx2:
            yy1=h-(xx1-offset); yy2=h-(xx2-offset)
            s.line(x+xx1,y+yy1,x+xx2,y+yy2,C['red'],1.6)

def rounded(value):
    return str(Decimal(str(value)).quantize(Decimal('.001'), rounding=ROUND_HALF_UP))

def cut_map():
    s=SVG(); s.header('WORKSHOP DETAIL 01 • BOTH DOORS • CUTS / MARKS: cm • STOCK: IMPERIAL','Exactly where to cut the frame','Half-lap joints: remove half the thickness from opposite faces, then overlap.')
    s.text(45,186,'Keep sound existing joints. Replacement stock: nominal 2×4, actual 1-1/2 × 3-1/2 in.',26,weight='bold')
    s.card(45,210,1710,337)
    s.text(75,253,'F1  UPRIGHT  ×4',31,weight='bold')
    s.text(1725,253,'CUT LENGTH 213.865 cm',29,anchor='end')
    s.text(75,289,'OUTSIDE broad face facing you  •  bottom at left; top at right',25,C['sub'])
    x,y,L=155,326,1490; sc=L/213.865; h=8.89*sc
    s.rect(x,y,L,h,C['wood'],C['ink'],2)
    zones=[(0,8.89),(102.4875,111.3775),(204.975,213.865)]
    for a,b in zones: waste(s,x+a*sc,y,(b-a)*sc,h)
    s.text(530,366,'HATCHED = WASTE',24,weight='bold',anchor='middle')
    s.text(1260,366,'REMOVE HALF DEPTH',24,weight='bold',anchor='middle')
    # All chain positions are calculated directly from the exact model coordinates.
    marks=[0,8.89,102.4875,111.3775,204.975,213.865]
    s.line(x,433,x+L,433,C['sub'],1.5)
    label_y=[469,502,469,502,502,469]
    for value,ty in zip(marks,label_y):
        xx=x+value*sc
        s.line(xx,y+h+3,xx,433,C['rule'],1.2)
        s.line(xx,425,xx,442,C['sub'],1.5)
        s.text(xx,ty,rounded(value),23,C['sub'],anchor='middle')
    s.text(75,531,'Notch depth = half the actual board thickness. For 1-1/2 in timber: cut 1.905 cm deep.',25,weight='bold')
    s.card(45,570,1710,330)
    s.text(75,613,'F2  CROSS RAIL  ×6',31,weight='bold')
    s.text(1725,613,'CUT LENGTH 127.565 cm',29,anchor='end')
    s.text(75,649,'INSIDE broad face facing you  •  a half-lap at each end',25,C['sub'])
    x,y,L=155,684,1490; sc=L/127.565; h=8.89*sc
    s.rect(x,y,L,h,C['wood'],C['ink'],2)
    for a,b in [(0,8.89),(118.675,127.565)]: waste(s,x+a*sc,y,(b-a)*sc,h)
    s.text(900,746,'FULL-WIDTH RAIL — THE ENDS OVERLAP THE UPRIGHTS',24,weight='bold',anchor='middle')
    marks=[0,8.89,118.675,127.565]
    s.line(x,816,x+L,816,C['sub'],1.5)
    for value,ty in zip(marks,[851,882,882,851]):
        xx=x+value*sc; s.line(xx,y+h+3,xx,816,C['rule'],1.2); s.line(xx,808,xx,824,C['sub'],1.5)
        s.text(xx,ty,rounded(value),23,C['sub'],anchor='middle')
    s.card(45,925,645,270)
    s.text(75,965,'SECTION THROUGH THE LAP',26,weight='bold')
    s.text(75,998,'Together, the two retained halves fill 1-1/2 in.',23,C['sub'])
    s.rect(90,1028,200,61,C['wood'],C['ink'],2)
    s.rect(90,1089,200,61,C['blue'],C['ink'],2)
    s.text(317,1069,'F2 retains OUTSIDE half',23,weight='bold')
    s.text(317,1128,'F1 retains INSIDE half',23,weight='bold')
    s.text(75,1180,'Each retained half = 3/4 in for this model.',23,C['sub'])
    s.card(710,925,1045,270)
    s.text(740,965,'EXACT LAYOUT MARKS',26,weight='bold')
    s.lines(740,1004,[
        'F1: 0–8.890  |  102.4875–111.3775  |  204.975–213.865',
        'F2: 0–8.890  |  118.675–127.565',
        'Measure from one squared end; mark with the actual mating board.',
        'The F2 rail is 127.565 cm long, including both overlaps.',
        'Do not use the clear opening between the uprights as cut length.'
    ],23,37,C['sub'])
    s.text(45,1241,'Cut maps are model dimensions, not site measurements. Verify timber, leaf size and squareness before cutting.',23,C['sub'])
    s.text(45,1277,'Cuts / layout marks: cm • Purchased stock: imperial • Rounded labels are not a cutting tolerance',22,C['sub'])
    return s.save('frame-half-lap-cut-map-cm')

def board(s,ox,oy,notch=False,mark=False,kerfs=False):
    def p(x,y,z): return (ox+x+.55*y,oy-.5*y-.9*z)
    def poly(coords,fill,stroke=None,sw=2): s.poly([p(*v) for v in coords],fill,stroke,sw)
    L,D,T,a,b=550,88.9,70,160,290
    # Display is an enlarged process schematic; true cut dimensions are on sheet 01.
    if notch:
        poly([(0,0,0),(L,0,0),(L,0,T),(b,0,T),(b,0,T/2),(a,0,T/2),(a,0,T),(0,0,T)],C['wood'])
        poly([(0,0,T),(a,0,T),(a,D,T),(0,D,T)],C['light'])
        poly([(a,0,T/2),(b,0,T/2),(b,D,T/2),(a,D,T/2)],C['blue'])
        poly([(b,0,T),(L,0,T),(L,D,T),(b,D,T)],C['light'])
        poly([(b,0,T/2),(b,D,T/2),(b,D,T),(b,0,T)],C['edge'])
    else:
        poly([(0,0,0),(L,0,0),(L,0,T),(0,0,T)],C['wood'])
        poly([(0,0,T),(L,0,T),(L,D,T),(0,D,T)],C['light'])
        poly([(a,0,T),(b,0,T),(b,D,T),(a,D,T)],C['waste'],C['red'])
        poly([(a,0,T/2),(b,0,T/2),(b,0,T),(a,0,T)],C['waste'],C['red'])
        if mark or kerfs:
            for cut in [a,b]:
                s.line(*p(cut,0,T/2),*p(cut,0,T),C['red'],4)
                s.line(*p(cut,0,T),*p(cut,D,T),C['red'],4)
        if kerfs:
            for cut in [182,203,224,245,266]:
                s.line(*p(cut,0,T/2+3),*p(cut,0,T),C['ink'],2.3)
                s.line(*p(cut,0,T),*p(cut,D,T),C['ink'],2.3)
    poly([(L,0,0),(L,D,0),(L,D,T),(L,0,T)],C['edge'])
    s.line(*p(0,0,T/2),*p(L,0,T/2),C['ink'],2,'9 7')
    return p

def how_to():
    s=SVG(); s.header('WORKSHOP DETAIL 02 • HANDSAW + SHARP CHISEL','Cut one test joint before cutting all pieces','Use two offcuts from your actual timber. Check face labels every time you turn a board.')
    s.text(45,184,'Clamp the board to a solid bench. Support the long length. Keep hands clear of the cutting path.',27,weight='bold')
    cards=[(45,215),(920,215),(45,704),(920,704)]
    for x,y in cards: s.card(x,y,835,457)
    x,y=cards[0]; s.text(x+28,y+49,'1  MARK THE SHOULDERS + HALF DEPTH',28,weight='bold')
    p=board(s,x+70,y+241,mark=True)
    s.dim(x+230,x+360,y+114,'actual mating width',22)
    s.arrow(x+598,y+287,*p(470,0,35),C['ink'],2)
    s.text(x+380,y+315,'depth line = half actual thickness',22,C['sub'])
    s.lines(x+28,y+355,[
        'Square the blank to length; label OUTSIDE and INSIDE.',
        'Use the mating board to mark the lap width. Knife the',
        'shoulders and mark half depth on both narrow edges.'
    ],24,32)
    x,y=cards[1]; s.text(x+28,y+49,'2  SAW THE SHOULDERS, THEN RELIEF CUTS',28,weight='bold')
    p=board(s,x+70,y+241,kerfs=True)
    s.text(x+370,y+100,'handsaw cuts in the waste',23,C['red'])
    s.arrow(x+397,y+112,*p(226,30,70),C['red'],2)
    s.text(x+85,y+293,'STOP short of the depth line; pare the last small amount.',22,C['red'],weight='bold')
    s.lines(x+28,y+355,[
        'Make a shallow starter on the waste side of the line.',
        'Middle notch: two shoulders. End lap: one shoulder.',
        'Add relief cuts; keep them above the depth line.'
    ],24,32)
    x,y=cards[2]; s.text(x+28,y+49,'3  REMOVE WASTE; PARE THE FLOOR FLAT',28,weight='bold')
    p=board(s,x+70,y+241,notch=True)
    # A symbolic chisel points toward the half-lap floor. No hand is placed in its path.
    target=p(225,25,35)
    bx,by=target
    s.poly([(bx-55.8,by-66.6),(bx-45.6,by-76.8),(bx+15,by-14),(bx,by)],'#b1bdc4',C['ink'],2)
    s.poly([(bx-87,by-104.4),(bx-69,by-117.6),(bx-45.6,by-76.8),(bx-55.8,by-66.6)],'#73553e',C['ink'],2)
    s.text(x+408,y+113,'chisel',23,C['sub'])
    s.arrow(x+458,y+124,bx-30,by-55,C['sub'],2)
    s.text(x+90,y+293,'Blue floor = the retained half. Finish exactly to the line.',22,C['sub'])
    s.lines(x+28,y+355,[
        'Remove small chips between the relief cuts.',
        'Work from each edge toward the middle; take thin cuts.',
        'Keep both hands behind the sharp edge. Pare flat.'
    ],24,32)
    x,y=cards[3]; s.text(x+28,y+49,'4  DRY-FIT THE OPPOSITE HALVES',28,weight='bold')
    # Readable section: complementary halves fill one thickness; the red line is the join.
    s.rect(x+72,y+132,605,144,C['blue'],C['ink'],2)
    s.rect(x+72,y+132,605,72,C['wood'],C['ink'],2)
    s.line(x+72,y+204,x+677,y+204,C['red'],2)
    s.text(x+373,y+181,'RAIL: retained OUTSIDE half',24,anchor='middle',weight='bold')
    s.text(x+373,y+253,'UPRIGHT: retained INSIDE half',24,anchor='middle',weight='bold')
    s.line(x+710,y+132,x+710,y+276,C['sub'],2)
    s.line(x+701,y+132,x+719,y+132,C['sub'],2); s.line(x+701,y+276,x+719,y+276,C['sub'],2)
    s.text(x+740,y+212,'1-1/2',22,C['sub'],anchor='middle')
    s.text(x+740,y+240,'in*',22,C['sub'],anchor='middle')
    s.lines(x+28,y+323,[
        'Broad faces flush; shoulders touching; no rocking.',
        'If tight, pare high spots; do not hammer the joint.',
        'If loose or overcut, remake it; do not fill for fit.',
        'Dry-fit the frame flat and check equal diagonals.'
    ],24,32)
    s.text(45,1200,'*For the nominal model. Match the real board thickness. Cutting diagrams do not specify structural joint fastening.',23,C['sub'])
    s.text(45,1239,'Method reference: Lee Valley Tools, “Mastering Handsaw Cuts” (Christopher Schwarz). Illustrations are original.',22,C['sub'])
    s.text(45,1277,'Cuts / marks: cm • Stock / equipment: imperial • Process diagrams are enlarged, not full-size templates',22,C['sub'])
    return s.save('frame-half-lap-handsaw-chisel-steps-cm')

if __name__ == '__main__':
    texts=[cut_map(),how_to()]
    combined=fitz.open()
    for name in ['frame-half-lap-cut-map-cm','frame-half-lap-handsaw-chisel-steps-cm']:
        doc=fitz.open(ROOT/(name+'.pdf')); combined.insert_pdf(doc)
    combined.save(ROOT/'frame-half-lap-workshop-details-cm.pdf')
    (ROOT/'frame-instructions.txt').write_text('''FRAME CUTTING — REPLACEMENT PIECES ONLY\nCuts and layout marks: centimeters. Purchased stock and equipment: imperial.\nStock for F1 and F2: nominal 2×4, actual 1-1/2 × 3-1/2 in. Do not rip the stock cross-section.\n\nF1 uprights: 4 pieces total, cut length 213.865 cm. Cut notches into the OUTSIDE broad face. Measure from the bottom squared end. Exact notch zones in cm: 0–8.890; 102.4875–111.3775; 204.975–213.865.\nF2 rails: 6 pieces total, cut length 127.565 cm. Cut into the INSIDE broad face. End notch zones in cm: 0–8.890; 118.675–127.565. The 127.565 cm length includes both overlaps; do not use the clear opening between the uprights as the blank length.\nFor actual 1-1/2 in thick boards, cut 1.905 cm deep into each mating member. Use half the measured thickness and the real mating board width. Both broad faces should finish flush when the complementary halves overlap, giving an assembled thickness of 1-1/2 in.\n\nSuggested low-complexity method:\n1. Make one trial joint in two offcuts from the actual timber. Square a blank, label both faces and the bottom. Transfer the actual mating board width with a square and knife. Mark half the thickness on the two narrow edges.\n2. Clamp and fully support the board. Make a shallow starter on the waste side of the shoulder line. Saw the shoulders on the waste side; then make several relief cuts within the waste. Stop just short of the depth line and finish with the chisel. Never cut below the line.\n3. Remove small chips with a sharp chisel. Work from each edge toward the middle, taking thin cuts and keeping both hands behind the cutting edge. Pare the floor flat to the line.\n4. Dry-fit. Faces flush, shoulders touching, no rocking. Pare only high spots if tight; remake a loose or overcut piece. Assemble the whole frame dry on a flat bench and compare the diagonals before applying adhesive.\n\nThe drawings show how to cut the established model. They do not verify the existing frame, timber condition, hardware load path or a structural fastening schedule. Retain sound existing joints instead of recutting an assembled frame.\n\nPrimary method reference: https://www.leevalley.com/en-gb/discover/woodworking/2020/august/mastering-handsaw-cuts\nRetrieved 2026-10-08. Supports knife-marking, a waste-side starter, bench clamping and handsaw shoulder cuts. Specific layout dimensions and the rest of the sequence are original project guidance.\n''')
    (ROOT/'validation.json').write_text(json.dumps({'geometry_units':'cm','display_units':{'cuts_and_layout':'cm','stock_and_equipment':'imperial'},'nominal_stock':'2x4','actual_stock_section_in':[1.5,3.5],'F1_qty':4,'F2_qty':6,'F1_zones':[[0,8.89],[102.4875,111.3775],[204.975,213.865]],'F2_zones':[[0,8.89],[118.675,127.565]],'F1_cut_face':'outside','F2_cut_face':'inside','nominal_half_depth_cm':1.905,'pdf_page_count':len(combined),'svg_render_text_counts':[len(t) for t in texts]},indent=2))
    print('Created two SVG/PNG/PDF sheets, combined PDF, instructions and validation.')
