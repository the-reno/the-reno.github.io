#!/usr/bin/env python3
"""Workshop illustrations: cuts/layout in cm; stock and hardware imperial.

Geometry is exact for layers and elevation. Fastener profiles are illustrative.
Inkscape makes the distributable PNG and vector PDF from the authored SVG.
"""
from pathlib import Path
import json, math, subprocess, html
from PIL import Image

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[1]
P = json.loads((PROJECT/'cad/parameters.json').read_text())
D = json.loads((PROJECT/'cad/derived_dimensions.json').read_text())
cm = lambda mm: mm/10
W, H = cm(D['leaf_width_mm']), cm(D['leaf_height_mm'])
TW, TD = cm(P['trim_face_width_mm']), cm(P['trim_thickness_mm'])
FW, FD = cm(P['frame_face_width_mm']), cm(P['core_depth_mm'])
PLY = cm(P['exterior_skin_thickness_mm'])
BEAR, GAP, INFILL = map(cm,D['meeting_stile_seam_support_chain_mm'])
RAIL = cm(D['trim_rail_cut_mm'][0])
T1_SCREW_CM = 3.937
REACH = T1_SCREW_CM-TD-PLY
TRIM_IN = TD/2.54
SCREW_IN = T1_SCREW_CM/2.54
REACH_IN = REACH/2.54
T1_POS = [5+i*(H-10)/9 for i in range(10)]
T2_POS = [5+i*(RAIL-10)/5 for i in range(6)]
assert abs(BEAR+GAP+INFILL-FW)<1e-10
assert abs(W-2*TW-RAIL)<1e-10
assert 0 < FW-TW < BEAR
assert INFILL > TW/2
FRAME_RAIL_BOTTOMS=list(map(cm,D['rail_lower_edges_from_leaf_bottom_mm']))
TRIM_RAIL_BOTTOMS=list(map(cm,D['trim_rail_lower_edges_from_leaf_bottom_mm']))
TRIM_FIXING_POINTS=[(xx,zz) for xx in [TW/2,W-TW/2] for zz in T1_POS]
TRIM_FIXING_POINTS += [(TW+xx,bb+TW/2) for bb in TRIM_RAIL_BOTTOMS for xx in T2_POS]
assert len(TRIM_FIXING_POINTS)==38
assert all(0<xx<W and 0<zz<H and (xx<FW or xx>W-FW or any(bb<zz<bb+FW for bb in FRAME_RAIL_BOTTOMS)) for xx,zz in TRIM_FIXING_POINTS)

C = dict(ink='#153939',muted='#50676b',bg='#f6f6f0',white='#ffffff',line='#849da0',
         teal='#23766f',trim='#cce3dd',ply='#ebcc93',wood='#dcba89',grain='#bd9360',
         orange='#d76520',blue='#28658d',pale='#e8edeb',seam='#914f86')

class SVG:
    def __init__(self,title,subtitle):
        self.parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1100" viewBox="0 0 1600 1100">',
                    '<defs><marker id="arr" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#50676b"/></marker></defs>']
        self.rect(0,0,1600,1100,C['bg'])
        self.rect(0,0,1600,147,C['ink'])
        self.text(55,48,'GARAGE DOORS / ASSEMBLY DETAIL',21,'#b7d6cc',weight='bold')
        self.text(55,97,title,42,'#ffffff',weight='bold')
        self.text(55,131,subtitle,23,'#dce9e4')
    def raw(self,v): self.parts.append(v)
    def rect(self,x,y,w,h,fill,stroke='none',sw=1,rx=0,opacity=1):
        self.raw(f'<rect x="{x:.4f}" y="{y:.4f}" width="{w:.4f}" height="{h:.4f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}" rx="{rx}" opacity="{opacity}"/>')
    def line(self,x1,y1,x2,y2,stroke=None,sw=2,dash=None,arrows=False):
        more=(f' stroke-dasharray="{dash}"' if dash else '') + (' marker-start="url(#arr)" marker-end="url(#arr)"' if arrows else '')
        self.raw(f'<line x1="{x1:.4f}" y1="{y1:.4f}" x2="{x2:.4f}" y2="{y2:.4f}" stroke="{stroke or C["line"]}" stroke-width="{sw}"{more}/>')
    def poly(self,points,fill='none',stroke=None,sw=2):
        self.raw(f'<polyline points="{" ".join(f"{x:.4f},{y:.4f}" for x,y in points)}" fill="{fill}" stroke="{stroke or C["line"]}" stroke-width="{sw}" stroke-linejoin="round"/>')
    def circle(self,x,y,r,fill,stroke='none',sw=1):
        self.raw(f'<circle cx="{x:.4f}" cy="{y:.4f}" r="{r:.4f}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
    def text(self,x,y,t,size=24,fill=None,weight='normal',anchor='start',rotate=None):
        transform=f' transform="rotate({rotate} {x} {y})"' if rotate is not None else ''
        self.raw(f'<text x="{x:.4f}" y="{y:.4f}" font-family="DejaVu Sans, sans-serif" font-size="{size}" font-weight="{weight}" fill="{fill or C["ink"]}" text-anchor="{anchor}"{transform}>{html.escape(str(t))}</text>')
    def lines(self,x,y,lines,size=23,gap=33,fill=None,weight='normal'):
        for i,t in enumerate(lines): self.text(x,y+i*gap,t,size,fill,weight)
    def hdim(self,x1,x2,y,label,size=23,above=True,color=None):
        self.line(x1,y-8,x1,y+8,color,1.5)
        self.line(x2,y-8,x2,y+8,color,1.5)
        self.line(x1+2,y,x2-2,y,color,1.5,arrows=True)
        if label: self.text((x1+x2)/2,y-13 if above else y+30,label,size,color,anchor='middle')
    def vdim(self,x,y1,y2,label,size=23):
        self.line(x-8,y1,x+8,y1,C['line'],1.5)
        self.line(x-8,y2,x+8,y2,C['line'],1.5)
        self.line(x,y1+2,x,y2-2,C['line'],1.5,arrows=True)
        self.text(x+16,(y1+y2)/2+8,label,size)
    def card(self,x,y,w,h,title,lines,accent=None):
        self.rect(x,y,w,h,C['white'],C['pale'],1,14)
        self.rect(x,y,7,h,accent or C['teal'],rx=3)
        self.text(x+24,y+39,title,27,accent or C['ink'],weight='bold')
        self.lines(x+24,y+77,lines,size=22,gap=31)
    def footer(self,line1,line2=None):
        self.line(55,1040,1545,1040,C['line'],1)
        self.text(55,1065,line1,20,C['muted'])
        if line2:self.text(55,1088,line2,16,C['muted'])
    def save(self,stem):
        p=HERE/f'{stem}.svg'
        p.write_text('\n'.join(self.parts+['</svg>']))
        subprocess.run(['inkscape',str(p),'--export-type=png','--export-width=1600',f'--export-filename={HERE/stem}.png'],check=True,capture_output=True)
        subprocess.run(['inkscape',str(p),'--export-type=pdf',f'--export-filename={HERE/stem}.pdf'],check=True,capture_output=True)
        with Image.open(HERE/f'{stem}.png') as im:
            assert im.size==(1600,1100)
            im.verify()

def screw(s,x,y,length,scale,col,broad=False,broken=False):
    """Symbol, not a manufactured screw profile; broad-head length deliberately broken."""
    width=17 if broad else 11
    # A countersunk head is flush with its receiving surface.
    s.poly([(x-width,y+1),(x+width,y+1),(x+4,y+12),(x-4,y+12),(x-width,y+1)],col,col,1)
    s.line(x-width+3,y+3,x+width-3,y+3,'#ffffff',1)
    yy=y+12
    end=y+length*scale
    s.line(x,yy,x,end-12,col,5)
    for z in range(round(yy+9),round(end-16),15):
        if broken and y+135<z<y+167:continue
        s.line(x-7,z,x+7,z-5,col,2)
    s.poly([(x-4,end-12),(x+4,end-12),(x,end),(x-4,end-12)],col,col,1)
    if broken:
        s.rect(x-10,y+135,20,32,C['wood'])
        s.poly([(x-9,y+140),(x+9,y+147),(x-9,y+154),(x+9,y+161)],stroke=col,sw=2)

def section():
    s=SVG('How the narrow strips are fixed',
          'LEFT meeting stile - top view - cuts / layout: cm; stock / hardware: imperial')
    for x,col,label in [(65,C['trim'],'T1 decorative trim'),(363,C['ply'],'P1 + P2 outside plywood'),(759,C['wood'],'F1 timber')]:
        s.rect(x,170,21,21,col,C['line'],1)
        s.text(x+32,189,label,22)
    k=80.0; x=180.0; yt=350.0
    xp=x+BEAR*k; xg=x+(BEAR+GAP)*k; edge=x+FW*k
    tx=edge-TW*k; yply=yt+TD*k; yf=yply+PLY*k; bottom=yf+FD*k
    # Geometry is drawn at one uniform exact scale.
    s.rect(x,yf,FW*k,FD*k,C['wood'],C['ink'],2)
    for i in range(1,9):
        gy=yf+FD*k*i/9
        s.poly([(x+8,gy),(x+260,gy-5),(x+435,gy+4),(edge-8,gy)],stroke=C['grain'],sw=1.0)
    s.rect(x-62,yply,BEAR*k+62,PLY*k,C['ply'],C['ink'],2)
    s.rect(xg,yply,INFILL*k,PLY*k,C['ply'],C['ink'],2)
    # Cut line at the left only says that the main plywood continues beyond the diagram.
    s.poly([(x-62,yply),(x-72,yply+22),(x-52,yply+45),(x-72,yply+69),(x-62,yf)],stroke=C['ink'],sw=2)
    s.rect(tx,yt,TW*k,TD*k,C['trim'],C['ink'],2)
    # Two screw paths shown in one section, but physically offset along height.
    x_t1=edge-(TW/2)*k
    x_p2=edge-(INFILL/2)*k
    screw(s,x_p2,yply,3.08,k,C['blue'],broad=True,broken=True)
    screw(s,x_t1,yt,T1_SCREW_CM,k,C['orange'])
    s.circle(x_t1,yt-31,18,C['orange'])
    s.text(x_t1,yt-24,'1',21,'#ffffff',weight='bold',anchor='middle')
    s.circle(x_p2,yply-31,18,C['blue'])
    s.text(x_p2,yply-24,'2',21,'#ffffff',weight='bold',anchor='middle')
    s.text(tx+22,yt+33,'T1',24,weight='bold')
    s.text(x+30,yply+58,'P1',28,weight='bold')
    s.text(edge-78,yply+58,'P2',28,weight='bold')
    s.text(x+35,yf+167,'F1 meeting stile',29,weight='bold')
    s.text(x+35,yf+203,'Sound timber behind both pieces',21)
    s.lines(95,276,['P1 continues','across the leaf'],21,gap=27)
    s.poly([(174,311),(145,333),(145,386)],stroke=C['muted'],sw=1.5)
    # Trim width and thickness chain.
    s.line(tx,yt-10,tx,277,C['line'],1)
    s.line(edge,yt-10,edge,277,C['line'],1)
    s.hdim(tx,edge,272,'T1 cut width 7.5 cm')
    s.text(edge,321,'OUTSIDE',19,C['muted'],anchor='end')
    for yy in [yt,yply,yf,bottom]: s.line(edge+8,yy,950,yy,C['line'],1)
    s.vdim(950,yt,yply,'0.236 in*',21)
    s.vdim(950,yply,yf,'15/32 in',21)
    s.vdim(950,yf,bottom,'1-1/2 in',21)
    # Plywood-to-stile bearing chain and separate total.
    for xx in [x,xp,xg,edge]: s.line(xx,bottom+9,xx,870,C['line'],1)
    s.hdim(x,xp,862,'P1 bearing 1.278 in',20)
    s.hdim(xp,xg,862,'')
    s.hdim(xg,edge,862,'P2 cut width 5.325 cm',23)
    s.line((xp+xg)/2,873,(xp+xg)/2,899,C['seam'],1.5)
    s.text((xp+xg)/2,925,'Set gap 0.32 cm',23,C['seam'],weight='bold',anchor='middle')
    s.line(x,883,x,976,C['line'],1)
    s.line(edge,883,edge,976,C['line'],1)
    s.hdim(x,edge,968,'2×4 stock: actual timber face 3-1/2 in',25)
    s.text(edge,1012,'Meeting edge of LEFT door',22,C['muted'],anchor='end')
    s.card(1090,215,455,260,'1  T1 finish screw',[
        'GRK #8 × 1-1/2 in; T10.',
        'Drawing length: 1.55 in.',
        'Geometric reach: 0.845 in.',
        'Axis: 3.75 cm from leaf edge.',
        'Pilot/countersink: test in',
        'your actual thin trim first.'
    ],C['orange'])
    s.card(1090,495,455,260,'2  P2 screw before trim',[
        'Broad bearing head; set flush.',
        'Do not crush the plywood.',
        'Axis: 2.663 cm from leaf edge.',
        'Select length for actual fixing.',
        'Offset from the T1 screws',
        'along the strip\'s height.'
    ],C['blue'])
    s.card(1090,775,455,238,'Keep the seam free',[
        'Do not rigidly glue T1 to',
        'both plywood pieces.',
        'The 0.32 cm gap remains',
        'behind the decorative trim.',
        'P2 screw length is schematic.'
    ],C['seam'])
    s.footer('Screw paths are offset along height; this schematic section shows both paths together.',
             '*Trim is 0.236 in in this model; verify actual stock (not exactly 1/4 in). Screw profile is illustrative; follow the screw maker.')
    s.save('fixing-strips-cross-section-cm')

def elevation():
    s=SVG('Where to screw the decorative trim',
          'Cuts / layout: cm - stock: 0.236 in exterior plywood trim in this model; verify actual stock')
    x,y,k=174.0,238.0,3.30
    ww,hh=W*k,H*k
    # Ghost frame is a geometrical reference, not a fixing schedule.
    s.rect(x,y,ww,hh,'#ffffff',C['ink'],2)
    for sx in [x,x+ww-FW*k]:
        s.rect(sx,y,FW*k,hh,'#e5e3d9',C['line'],1,opacity=.85)
    for b in D['rail_lower_edges_from_leaf_bottom_mm']:
        ry=y+hh-(cm(b)+FW)*k
        s.rect(x,ry,ww,FW*k,'#e5e3d9',C['line'],1,opacity=.85)
    # Continuous verticals and three between-stile trim rails.
    for sx in [x,x+ww-TW*k]: s.rect(sx,y,TW*k,hh,C['trim'],C['teal'],1.5)
    trim_bottoms=list(map(cm,D['trim_rail_lower_edges_from_leaf_bottom_mm']))
    for b in trim_bottoms:
        ry=y+hh-(b+TW)*k
        s.rect(x+TW*k,ry,RAIL*k,TW*k,C['trim'],C['teal'],1.5)
    # Dashed centerlines establish exact screw placement.
    for sx in [x+TW*k/2,x+ww-TW*k/2]:
        s.line(sx,y+4,sx,y+hh-4,C['teal'],1,dash='7 5')
        for pos in T1_POS:
            s.circle(sx,y+hh-pos*k,4.6,C['orange'],C['white'],1.1)
    for b in trim_bottoms:
        cy=y+hh-(b+TW/2)*k
        s.line(x+TW*k+4,cy,x+ww-TW*k-4,cy,C['teal'],1,dash='7 5')
        for pos in T2_POS:
            s.circle(x+(TW+pos)*k,cy,4.6,C['orange'],C['white'],1.1)
    # Overall reference envelope.
    s.line(x,y-10,x,192,C['line'],1)
    s.line(x+ww,y-10,x+ww,192,C['line'],1)
    s.hdim(x,x+ww,198,'Cut envelope 127.565 cm',24)
    s.line(119,y,x-9,y,C['line'],1)
    s.line(119,y+hh,x-9,y+hh,C['line'],1)
    s.line(120,y+3,120,y+hh-3,C['line'],1.5,arrows=True)
    s.text(86,y+hh/2,'Cut envelope 213.865 cm',25,anchor='middle',rotate=-90)
    # Inside fields stay clear; outside labels point to each part family.
    s.text(x+ww/2,y+hh*.25,'Continuous plywood face',21,C['muted'],anchor='middle')
    s.text(x+ww/2,y+hh*.25+30,'beneath the trim',21,C['muted'],anchor='middle')
    s.text(x+ww/2,y+hh*.72,'LEFT leaf shown',22,C['muted'],anchor='middle')
    s.text(x+ww/2,y+hh*.72+31,'Mirror for the RIGHT leaf',20,C['muted'],anchor='middle')
    s.text(637,362,'T1',29,C['teal'],weight='bold')
    s.poly([(631,367),(610,385),(x+ww-TW*k/2,y+180)],stroke=C['teal'],sw=1.5)
    s.text(637,580,'T2',29,C['teal'],weight='bold')
    s.poly([(631,585),(608,585),(x+ww-35,y+hh/2)],stroke=C['teal'],sw=1.5)
    s.circle(174,991,5,C['orange'])
    s.text(192,999,'Screw',21)
    s.rect(304,981,20,20,C['trim'],C['teal'],1)
    s.text(334,999,'Trim',21)
    s.rect(426,981,20,20,'#e5e3d9',C['line'],1)
    s.text(456,999,'Timber behind',21)

    def strip_card(yy,title,dims,number,spacing,length):
        s.rect(802,yy,742,268,C['white'],C['pale'],1,14)
        s.text(827,yy+40,title,29,C['teal'],weight='bold')
        s.text(827,yy+76,dims,24)
        s.text(827,yy+113,f'{number} screws per strip',26,weight='bold')
        bx,by,bw,bh=843,yy+147,636,42
        s.rect(bx,by,bw,bh,C['trim'],C['teal'],1.5)
        scale=bw/length
        positions=T1_POS if number==10 else T2_POS
        for p in positions:
            s.circle(bx+p*scale,by+bh/2,5,C['orange'],C['white'],1)
        s.line(bx+5,by+bh/2,bx+bw-5,by+bh/2,C['teal'],1,dash='6 5')
        for p in positions:s.circle(bx+p*scale,by+bh/2,5,C['orange'],C['white'],1)
        s.text(827,yy+227,f'5 cm end margin + {number-1} equal gaps of {spacing:.3f} cm + 5 cm',22)
        s.text(827,yy+254,'Screw row: 3.75 cm from either long edge.',21,C['muted'])
    strip_card(171,'T1 / 2 vertical strips per leaf','Cut 213.865 × 7.5 cm; stock 0.236 in thick',10,(H-10)/9,H)
    strip_card(458,'T2 / 3 horizontal strips per leaf','Cut 112.565 × 7.5 cm; stock 0.236 in thick',6,(RAIL-10)/5,RAIL)
    s.rect(802,746,742,271,C['ink'],rx=14)
    s.text(830,793,'38 screws per leaf',37,'#ffffff',weight='bold')
    s.text(830,831,'2 × 10 + 3 × 6 = 38     |     76 for both leaves',25,'#dce9e4')
    s.text(830,878,'DECORATIVE TRIM ONLY',24,'#efd0a6',weight='bold')
    s.lines(830,914,[
        'This is not the frame, hinge or plywood fixing schedule.',
        'Every trim fixing must enter sound timber underneath.',
        'Center cover C1 and any extra hardware are excluded.'
    ],22,gap=32,fill='#ffffff')
    s.footer('Proposed screw layout for lightweight, flat trim. Confirm the actual materials and fixing product before cutting or drilling.',
             'All orange dots land over modeled timber. Cut/layout values are not workshop tolerances. Model 0.236 in trim is not exactly 1/4 in.')
    s.save('decorative-trim-screw-layout-cm')

section();elevation()
metadata={
    'source_parameters':'cad/parameters.json',
    'source_derived_dimensions':'cad/derived_dimensions.json',
    'geometry_units':'cm','display_units':{'cuts_and_layout':'cm','stock_and_hardware':'imperial'},'reference_status':'provisional V4 geometry',
    'stock_and_hardware_imperial':{'nominal_timber':'2x4','actual_timber_section_in':[1.5,3.5],
                                  'exterior_plywood_in':'15/32','model_trim_thickness_in':TRIM_IN,
                                  'trim_is_not_exactly_quarter_inch':True,
                                  'trim_screw_pack':'GRK FIN/Trim #8 x 1-1/2 in','driver':'T10',
                                  'trim_screw_drawing_length_in':SCREW_IN,'wood_reach_example_in':REACH_IN},
    'leaf':{'width':W,'height':H},
    'section':{'timber_face':FW,'timber_depth':FD,'plywood_thickness':PLY,
               'main_sheet_bearing':BEAR,'movement_gap':GAP,'infill_width':INFILL,
               'trim_width':TW,'trim_thickness':TD,
               'trim_screw_axis_from_meeting_edge':TW/2,
               'infill_screw_axis_from_meeting_edge':INFILL/2,
               'trim_screw_overall_example':T1_SCREW_CM,'wood_reach_example':REACH,
               'infill_screw_length':'schematic; not specified',
               'screw_sections':'offset along leaf height; schematic composite section'},
    'proposed_trim_layout':{'t1_screw_positions_from_one_end':T1_POS,
                            't2_screw_positions_from_one_end':T2_POS,
                            't1_gaps':(H-10)/9,'t2_gaps':(RAIL-10)/5,
                            'end_margin':5,'per_leaf':38,'both_leaves':76,
                            'all_38_fixings_checked_inside_modeled_timber':True,
                            'excludes':['frame','hinges','skin fasteners','center cover','extra hardware'],
                            'assumes':'lightweight, flat, sound exterior plywood trim; model 0.236 in thick, verify actual stock'},
    'rendering':'1600 × 1100 px PNG and vector PDF/SVG from same deterministic source',
    'files':[f'{n}.{ext}' for n in ['fixing-strips-cross-section-cm','decorative-trim-screw-layout-cm'] for ext in ['svg','png','pdf']],
}
(HERE/'strip-diagrams-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'ok':True,'output':str(HERE),'files':metadata['files'],'per_leaf_screws':38,'both_leaves_screws':76},indent=2))
