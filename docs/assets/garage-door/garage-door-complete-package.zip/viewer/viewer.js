(function () {
  'use strict';
  const root = document.getElementById('garage-door-execution');
  const $ = s => root.querySelector(s);
  const canvas = $('[data-scene]'), ctx = canvas.getContext('2d');
  const modeInput=$('[data-mode]'), stepInput=$('[data-step]'), angleInput=$('[data-angle]');
  const explodeInput=$('[data-exploded]'), openingInput=$('[data-opening]');
  const layerInput=$('[data-layers]'), unitInput=$('[data-units]'), dimensionInput=$('[data-dimensions]');
  const partInput=$('[data-part-select]'), instruction=$('[data-instruction]');
  const openingValue=$('[data-opening-value]'), play=$('[data-play]');
  const CAD=/*__CAD_JSON__*/null;
  const D=Object.freeze({openingWidth:2570,openingHeight:2160,sideGap:6.35,topGap:6.35,bottomGap:15,gap:6,
    leafWidth:1275.65,leafHeight:2138.65,baseZ:15,outside:11.90625,core:38.1,inside:5.08,body:55.08625,
    stile:88.9,trim:6,trimWidth:75,mainSkinWidth:1219.2,skinJoint:3.2,skinStripWidth:53.25,foamGap:1.5,
    spacerWidth:30,spacer:3,coverWidth:60,cover:6,leftOverlap:24,gasketWidth:22,gasketCompressed:3,
    sectionHeight:300,hingeY:-34,hingeX:1278.65});
  const state={mode:'whole',step:1,camera:'3d',yaw:-.38,pitch:-.16,zoom:1,exploded:0,opening:0,
    selected:null,animating:false,layers:'all',units:'in',dimensions:true,hardware:false};
  const rad=Math.PI/180, clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const mix=(a,b,t)=>a.map((v,i)=>v*(1-t)+b[i]*t);
  const steps=[
    ['1 · Fit the frame','Measure the opening and both diagonals. Inspect the existing 2×4 timber, then fit two full-height stiles and three full-width rails. For replacements, cut stiles 213.865 cm long and rails 127.565 cm long. The half-lap cuts are 8.89 cm long × 1.905 cm deep. Preserve sound existing joints; select adhesive, reinforcement and fasteners for the actual timber and loads.'],
    ['2 · Fit the outside skin','Use 15/32-inch plywood. Cut each main panel 213.865 × 121.92 cm and its edge strip 213.865 × 5.325 cm; set a 0.32 cm movement joint. Both sheet edges land on the continuous meeting stile. Confirm the actual sheet width and exterior exposure rating before cutting.'],
    ['3 · Fit the insulation','Use 1-1/2-inch rigid insulation that fits flush within the frame cavity, including its adhesive bed. Cut two example inserts per leaf at 109.485 × 93.2975 cm, setting 0.15 cm clearance at each edge. Use a foam-compatible adhesive or edge treatment suited to the selected product.'],
    ['4 · Close the inside','Use the confirmed 1/5-inch inside plywood. Cut the main panel 213.865 × 121.92 cm and edge strip 213.865 × 5.325 cm. Dry-fit first; set the 0.32 cm movement joint beneath the cover trim.'],
    ['5 · Apply the trim','Cut trim 7.5 cm wide from the existing stock, modeled at 0.236 in thick; verify its actual thickness. Per leaf, cut two stiles 213.865 cm long and three rails 112.565 cm long. The meeting trim conceals the plywood joint; keep that joint free to move and finish exposed faces and edges.'],
    ['6 · Fit the right spacer','Cut the spacer 3 cm wide and fit it on the RIGHT meeting trim only. Its illustrated thickness is 0.118 in; select the actual stock to match the chosen seal’s compressed working gap. Fit the final length to the installed end seals.'],
    ['7 · Fit the cover and seal','Cut the cover 6 cm wide from 0.236 in model stock and fit its final length. Apply the 0.866 in wide example gasket within the 2.4 cm left overhang. Attach the supported right 3 cm side through the spacer and trim into solid right-hand timber. The left leaf remains free.'],
    ['8 · Hang, align and test','Have the actual hinge, post attachment and door weight checked before hanging. Secure the left leaf first and close the right last. Verify the center seal, end transitions, bottom clearance and the entire opening sweep on the actual garage.']
  ];
  const descriptions={
    timber:'Existing nominal 2×4 stock shown flat: actual 3-1/2 in face × 1-1/2 in depth. Replacement half-lap cuts are 8.89 cm long × 1.905 cm deep, with full-width rails. Retain sound existing framing and joints where appropriate; bonding, reinforcement and fixings remain to be selected.',
    outside:'15/32-inch exterior face plywood. Main sheet and edge strip are supported by the continuous meeting stile. Verify the product exposure rating and actual thickness.',
    inside:'Confirmed 1/5-inch plywood on the inside. Verify the actual stock thickness before fitting it flush to the frame.',
    foam:'Use 1-1/2-inch rigid foam, fitted flush with the wood including its adhesive bed. Fix screws into timber backing. Set 0.15 cm clearance around each insert.',
    trim:'Cut applied outside trim 7.5 cm wide. Thickness is 0.236 in in this model, not exactly 1/4 in; verify actual stock. The trim creates two panel fields and conceals the supported plywood joint.',
    spacer:'Cut the spacer 3 cm wide and attach it to the right trim only. The 0.118 in example thickness must be adjusted for the selected gasket’s compressed working gap.',
    cover:'Exterior overlap strip / astragal / mata-junta. It attaches only to the right leaf. Layout marks: 3 cm support + 0.6 cm center gap + 2.4 cm left overlap = 6 cm cut width. Model stock thickness is 0.236 in.',
    hardware:'Schematic appearance reference only. These are not selected, rated, drilled or specified pieces of hardware. Use the final selected hardware dimensions and installation requirements; do not fabricate or purchase from this envelope.',
    gasket:'Example compressible gasket on the back of the cover, entirely within the left overhang. Width 0.866 in and compressed depth 0.118 in are an illustrative fit, not a selected product specification.'
  };
  const names={timber:'Timber',outside:'Outside plywood',inside:'Inside plywood',foam:'Insulation',trim:'Outside trim',spacer:'Right spacer',cover:'Center cover',gasket:'Center gasket'};
  const colorMap={timber:[197,157,107],outside:[239,237,224],inside:[224,218,196],foam:[137,187,204],trim:[251,250,243],spacer:[203,151,93],cover:[252,251,246],gasket:[44,51,50],hardware:[48,57,56]};
  let frame=null,parts=[],renderedPixels=null,sequence=0;
  const colors={bg:[246,247,242],fg:[33,50,49],line:[133,144,138],accent:[30,120,119],...colorMap};
  const rgb=c=>'rgb('+c.map(v=>Math.round(clamp(v,0,255))).join(',')+')';
  const fmt=v=>state.units==='in'?(v/25.4).toFixed(3).replace(/\.?0+$/,''):v.toFixed(2).replace(/\.?0+$/,'');
  const sizeText=p=>{const b=p.bounds;return [b[1]-b[0],b[5]-b[4],b[3]-b[2]].map(fmt).join(' × ')+' '+state.units;};
  function box(id,role,leaf,label,x0,x1,y0,y1,z0,z1,stage){
    const vertices=[[x0,y0,z0],[x1,y0,z0],[x1,y1,z0],[x0,y1,z0],[x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1]];
    return {id,role,leaf,label,stage,vertices,bounds:[x0,x1,y0,y1,z0,z1],faces:[[0,3,2,1],[4,5,6,7],[0,1,5,4],[3,7,6,2],[0,4,7,3],[1,2,6,5]]};
  }

  function meshEdges(p){
    const entries=new Map(),key=i=>p.vertices[i].map(v=>v.toFixed(5)).join(',');
    for(const tri of p.triangles){
      const n=normal(...tri.map(i=>p.vertices[i]));
      for(let j=0;j<3;j++){
        const a=tri[j],b=tri[(j+1)%3],ka=key(a),kb=key(b),k=ka<kb?ka+'|'+kb:kb+'|'+ka;
        const item=entries.get(k);if(item)item.normals.push(n);else entries.set(k,{a,b,normals:[n]});
      }
    }
    return [...entries.values()].filter(e=>e.normals.length===1||e.normals.some(n=>n.reduce((sum,v,i)=>sum+v*e.normals[0][i],0)<.95)).map(e=>[e.a,e.b]);
  }
  const roleMap={frame_stile:'timber',frame_rail:'timber',insulation:'foam',skin_exterior:'outside',skin_interior:'inside',
    decorative_trim_stile:'trim',decorative_trim_rail:'trim',center_spacer:'spacer',center_cover:'cover',gasket_reference:'gasket',
    hinge_reference:'hardware',hinge_pin_reference:'hardware',pull_reference:'hardware'};
  const stages={timber:1,outside:2,foam:3,inside:4,trim:5,spacer:6,cover:7,gasket:7,hardware:8};
  function partLabel(name){
    return name.replace(/^(REFERENCE_)?(LEFT_INACTIVE|RIGHT_ACTIVE)_/,'').replace('FRAME_STILE_','').replace('FRAME_RAIL_','')
      .replace('EXTERIOR_SKIN_','OUTSIDE ').replace('INTERIOR_SKIN_','INSIDE ').replace('INFILL','EDGE STRIP')
      .replace('MAIN','MAIN PANEL').replace('TRIM_STILE_','TRIM ').replace('TRIM_RAIL_','TRIM ').replace('FOAM_1','LOWER INSULATION')
      .replace('FOAM_2','UPPER INSULATION').replace(/_/g,' ').toLowerCase().replace(/^./,c=>c.toUpperCase());
  }
  const canonical=CAD.parts.filter(p=>roleMap[p.role]).map(p=>{
    const b=p.bounds_mm,role=roleMap[p.role];
    let label=partLabel(p.name);if(p.role==='frame_stile')label+=' stile';if(p.role==='frame_rail')label+=' rail';
    return {id:p.name,role,leaf:p.leaf==='RIGHT_ACTIVE'?'RIGHT':'LEFT',label,stage:stages[role],vertices:p.vertices,faces:p.triangles,
      bounds:[b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax],mesh:true,edges:meshEdges(p),moving:p.moving,
      reference:p.is_reference,blank:p.blank_dimensions_mm,material:p.material};
  });
  function compound(id,label,blocks){
    const vertices=[],faces=[];
    for(const p of blocks){const n=vertices.length;vertices.push(...p.vertices);faces.push(...p.faces.map(f=>f.map(i=>i+n)));}
    const original=canonical.find(p=>p.id===id),xs=vertices.map(v=>v[0]),ys=vertices.map(v=>v[1]),zs=vertices.map(v=>v[2]);
    return {...original,label,vertices,faces,mesh:false,edges:[],crop:true,bounds:[Math.min(...xs),Math.max(...xs),Math.min(...ys),Math.max(...ys),Math.min(...zs),Math.max(...zs)]};
  }
  function lapParts(){
    const x=3,y=D.outside,z=D.baseZ,f=D.stile,t=D.core,half=t/2,L=360;
    const b=(x0,x1,y0,y1,z0,z1)=>box('','timber','RIGHT','',x0,x1,y0,y1,z0,z1,1);
    return [
      compound('RIGHT_ACTIVE_FRAME_STILE_MEETING','Meeting stile · cropped end',[
        b(x,x+f,y+half,y+t,z,z+L),b(x,x+f,y,y+half,z+f,z+L)]),
      compound('RIGHT_ACTIVE_FRAME_RAIL_BOTTOM','Bottom rail · cropped end',[
        b(x+f,x+L,y,y+t,z,z+f),b(x,x+f,y,y+half,z,z+f)])
    ];
  }
  function makeParts(mode=state.mode){
    if(mode==='lap')return lapParts();
    if(mode!=='joint')return canonical.filter(p=>(mode==='whole'||p.leaf==='RIGHT')&&(p.role!=='hardware'||state.hardware));
    // A 300 mm crop between rails: the same layer datums and supported seam as the full CAD.
    const out=[],h=D.sectionHeight,edge=156,core0=D.outside,core1=D.outside+D.core;
    for(const side of ['LEFT','RIGHT']){
      const right=side==='RIGHT',a=right?3:-edge,b=right?edge:-3,m0=right?3:-3-D.stile,m1=right?3+D.stile:-3;
      out.push(box(side+'_meeting_stile','timber',side,'Meeting stile · section',m0,m1,core0,core1,0,h,1));
      for(const [role,y0,y1,stage] of [['outside',0,D.outside,2],['inside',core1,D.body,4]]){
        out.push(box(side+'_'+role+'_main',role,side,(role==='outside'?'Outside':'Inside')+' main skin · section',right?3+D.skinStripWidth+D.skinJoint:a,right?b:-3-D.skinStripWidth-D.skinJoint,y0,y1,0,h,stage));
        out.push(box(side+'_'+role+'_strip',role,side,(role==='outside'?'Outside':'Inside')+' edge strip · section',right?3:-3-D.skinStripWidth,right?3+D.skinStripWidth:-3,y0,y1,0,h,stage));
      }
      out.push(box(side+'_foam','foam',side,'Insulation · section',right?m1:a,right?b:m0,core0,core1,0,h,3));
      out.push(box(side+'_meeting_trim','trim',side,'Meeting-edge trim · section',right?3:-3-D.trimWidth,right?3+D.trimWidth:-3,-D.trim,0,0,h,5));
    }
    out.push(box('spacer','spacer','RIGHT','Right spacer · section',3,33,-9,-6,0,h,6));
    out.push(box('cover','cover','RIGHT','Center overlap cover · section',-27,33,-15,-9,0,h,7));
    out.push(box('gasket','gasket','RIGHT','Center gasket · compressed section',-26,-4,-9,-6,0,h,7));
    return out;
  }
  function angles(p=state.opening){return {RIGHT:Math.min(p*1.8,90),LEFT:Math.max(0,(p-50)*1.8)};}
  function offset(part){
    if(!state.exploded)return 0;
    if(state.mode==='lap')return part.id.includes('RAIL')?-110:0;
    const close=state.mode==='joint';
    const values=close?{timber:0,foam:36,outside:-48,inside:58,trim:-89,spacer:-124,cover:-169,gasket:-151}:
      {timber:0,foam:280,outside:-480,inside:720,trim:-850,spacer:-1130,cover:-1450,gasket:-1320};
    return (values[part.role]||0)*state.exploded;
  }
  function world(p,part){
    const v=[p[0],p[1]+offset(part),p[2]];if(part.moving===false)return v;
    const a=angles()[part.leaf]*(part.leaf==='RIGHT'?1:-1)*rad;
    const px=(part.leaf==='RIGHT'?1:-1)*D.hingeX,py=D.hingeY,x=v[0]-px,y=v[1]-py,c=Math.cos(a),s=Math.sin(a);
    return [px+x*c-y*s,py+x*s+y*c,v[2]];
  }
  function view(p){
    const c=Math.cos(state.yaw),s=Math.sin(state.yaw),cp=Math.cos(state.pitch),sp=Math.sin(state.pitch);
    const x=p[0]*c+p[1]*s,y=-p[0]*s+p[1]*c;
    return [x,p[2]*cp-y*sp,y*cp+p[2]*sp];
  }
  function visible(p){
    if(state.mode==='build')return p.stage<=state.step;
    if(!['joint','lap'].includes(state.mode)&&state.layers!=='all')return p.role==='timber'||(state.layers==='core'&&p.role==='foam');
    return true;
  }
  function highlighted(p){
    if(state.selected)return p.id===state.selected;
    return state.mode==='build'&&p.stage===state.step;
  }
  function normal(a,b,c){
    const u=b.map((v,i)=>v-a[i]),v=c.map((n,i)=>n-a[i]);
    const n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]],l=Math.hypot(...n)||1;
    return n.map(v=>v/l);
  }
  function rasterize(faces,width,height,scale){
    const pixels=ctx.createImageData(width,height),rgba=pixels.data;
    const depths=new Float32Array(width*height);depths.fill(Infinity);
    function triangle(a,b,c,fill){
      const det=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);
      if(Math.abs(det)<1e-9)return;
      const xmin=Math.max(0,Math.floor(Math.min(a[0],b[0],c[0]))),xmax=Math.min(width-1,Math.ceil(Math.max(a[0],b[0],c[0])));
      const ymin=Math.max(0,Math.floor(Math.min(a[1],b[1],c[1]))),ymax=Math.min(height-1,Math.ceil(Math.max(a[1],b[1],c[1])));
      if(xmin>xmax||ymin>ymax)return;
      const ux=(b[1]-c[1])/det,uy=(c[0]-b[0])/det,vx=(c[1]-a[1])/det,vy=(a[0]-c[0])/det;
      let ur=ux*(xmin+.5-c[0])+uy*(ymin+.5-c[1]),vr=vx*(xmin+.5-c[0])+vy*(ymin+.5-c[1]);
      const red=Math.round(fill[0]),green=Math.round(fill[1]),blue=Math.round(fill[2]);
      for(let y=ymin;y<=ymax;y++,ur+=uy,vr+=vy){
        let u=ur,v=vr,index=y*width+xmin;
        for(let x=xmin;x<=xmax;x++,index++,u+=ux,v+=vx){
          const w=1-u-v;if(u< -1e-7||v< -1e-7||w< -1e-7)continue;
          const z=u*a[2]+v*b[2]+w*c[2];
          if(z>depths[index])continue;
          depths[index]=z;const i=index*4;rgba[i]=red;rgba[i+1]=green;rgba[i+2]=blue;rgba[i+3]=255;
        }
      }
    }
    // Every opaque surface competes at each pixel, regardless of part size or draw order.
    for(const f of faces){if(f.ghost||f.outlineOnly)continue;for(let i=1;i<f.points.length-1;i++)triangle(f.points[0],f.points[i],f.points[i+1],f.fill);}
    // Outline segments use the same depth buffer, so buried foam/skin edges stay hidden.
    const bias=.18/scale+1e-4;
    for(const f of faces){
      if(f.noOutline)continue;
      const stroke=f.ghost?mix(colors.bg,colors.fg,.18):f.stroke;
      for(let i=0;i<f.points.length;i++){
        const a=f.points[i],b=f.points[(i+1)%f.points.length],dx=b[0]-a[0],dy=b[1]-a[1],dz=b[2]-a[2];
        const count=Math.max(1,Math.ceil(Math.max(Math.abs(dx),Math.abs(dy))*2));
        for(let j=0;j<=count;j++){
          const t=j/count,x=Math.floor(a[0]+dx*t),y=Math.floor(a[1]+dy*t);
          if(x<0||x>=width||y<0||y>=height)continue;
          const z=a[2]+dz*t,index=y*width+x;if(z>depths[index]+bias)continue;
          depths[index]=Math.min(depths[index],z);const k=index*4;
          rgba[k]=Math.round(stroke[0]);rgba[k+1]=Math.round(stroke[1]);rgba[k+2]=Math.round(stroke[2]);rgba[k+3]=255;
        }
      }
    }
    return pixels;
  }

  function dimensions(){
    if(!state.dimensions||state.opening||state.exploded)return [];
    const ortho=['front','inside','top'].includes(state.camera);
    if(!ortho)return [];
    const m=(a,b,label)=>({a,b,label});
    if(state.mode==='lap')return state.camera==='front'?[m([3,0,-30],[91.9,0,-30],'8.89 cm lap cut')]:[];
    if(state.mode==='joint'&&state.camera==='top')return [
      m([-27,-34,300],[33,-34,300],fmt(60)+' '+state.units+' cover')
    ];
    if(state.camera==='top')return [];
    if(state.mode==='joint')return [m([-27,-20,327],[33,-20,327],fmt(60)+' '+state.units+' cover')];
    const single=state.mode==='leaf'||state.mode==='build';
    if(single)return [
      m([3,0,-85],[D.hingeX,0,-85],fmt(D.leafWidth)+' '+state.units),
      m([D.hingeX+135,0,D.baseZ],[D.hingeX+135,0,D.baseZ+D.leafHeight],fmt(D.leafHeight)+' '+state.units)
    ];
    return [
      m([-1285,0,-145],[1285,0,-145],fmt(D.openingWidth)+' '+state.units+' assumed opening'),
      m([-D.hingeX,0,2240],[-3,0,2240],fmt(D.leafWidth)+' '+state.units+' leaf'),
      m([D.hingeX+160,0,0],[D.hingeX+160,0,D.openingHeight],fmt(D.openingHeight)+' '+state.units)
    ];
  }
  function drawDimension(dim,project){
    const a=project(view(dim.a)),b=project(view(dim.b)),dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy)||1;
    const nx=-dy/len,ny=dx/len,cx=(a[0]+b[0])/2,cy=(a[1]+b[1])/2;
    ctx.strokeStyle=rgb(colors.accent);ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(a[0],a[1]);ctx.lineTo(b[0],b[1]);
    for(const p of [a,b]){ctx.moveTo(p[0]-nx*4,p[1]-ny*4);ctx.lineTo(p[0]+nx*4,p[1]+ny*4);}ctx.stroke();
    const vertical=Math.abs(dy)>Math.abs(dx)*1.8,fontSize=12;
    ctx.save();ctx.translate(cx,cy);if(vertical)ctx.rotate(-Math.PI/2);
    ctx.font=fontSize+'px system-ui, sans-serif';ctx.textAlign='center';ctx.textBaseline='middle';
    const w=ctx.measureText(dim.label).width;ctx.fillStyle=rgb(colors.bg);ctx.fillRect(-w/2-5,-10,w+10,20);
    ctx.fillStyle=rgb(colors.accent);ctx.fillText(dim.label,0,0);ctx.restore();
    return {text:dim.label,x:cx,y:cy,vertical,a,b};
  }
  function draw(){
    const width=Math.max(1,Math.round(canvas.clientWidth)),height=Math.max(1,Math.round(canvas.clientHeight));
    if(canvas.width!==width||canvas.height!==height){canvas.width=width;canvas.height=height;}
    ctx.setTransform(1,0,0,1,0,0);ctx.clearRect(0,0,width,height);
    parts=makeParts().filter(visible);
    const entries=parts.map(p=>{const w=p.vertices.map(v=>world(v,p));return {part:p,world:w,view:w.map(view)};});
    const dims=dimensions();let xmin=Infinity,xmax=-Infinity,ymin=Infinity,ymax=-Infinity;
    const allPoints=entries.flatMap(e=>e.view).concat(dims.flatMap(d=>[view(d.a),view(d.b)]));
    for(const p of allPoints){xmin=Math.min(xmin,p[0]);xmax=Math.max(xmax,p[0]);ymin=Math.min(ymin,p[1]);ymax=Math.max(ymax,p[1]);}
    const margin=state.mode==='joint'?42:45;
    const scale=Math.min((width-margin*2)/Math.max(1,xmax-xmin),(height-margin*2)/Math.max(1,ymax-ymin))*state.zoom;
    const cx=(xmin+xmax)/2,cy=(ymin+ymax)/2;
    const project=p=>[(p[0]-cx)*scale+width/2,height/2-(p[1]-cy)*scale,p[2]],faces=[];
    for(const e of entries){
      e.screen=e.view.map(project);
      for(const indices of e.part.faces){
        const vv=indices.map(i=>e.view[i]),n=normal(vv[0],vv[1],vv[2]);if(n[2]<=.00001)continue;
        const shade=.025+.2*(1-Math.abs(n[1])*.3-Math.abs(n[2])*.7);
        let fill=mix(colors[e.part.role]||colors.trim,colors.bg,shade);
        if(highlighted(e.part))fill=mix(fill,colors.accent,.22);
        faces.push({id:e.part.id,role:e.part.role,leaf:e.part.leaf,world:indices.map(i=>e.world[i]),points:indices.map(i=>e.screen[i]),
          depth:vv.reduce((s,p)=>s+p[2],0)/vv.length,fill,stroke:highlighted(e.part)?colors.accent:colors.line,ghost:false,noOutline:!!e.part.mesh});
      }
    }
    for(const e of entries)if(e.part.mesh)for(const indices of e.part.edges){faces.push({id:e.part.id,role:e.part.role,leaf:e.part.leaf,world:indices.map(i=>e.world[i]),points:indices.map(i=>e.screen[i]),depth:0,fill:colors[e.part.role],stroke:highlighted(e.part)?colors.accent:colors.line,ghost:false,outlineOnly:true});}
    renderedPixels=rasterize(faces,width,height,scale);ctx.putImageData(renderedPixels,0,0);
    const labels=dims.map(d=>drawDimension(d,project));
    frame={width,height,scale,cx,cy,faces,labels,parts:entries.map(e=>({id:e.part.id,role:e.part.role,leaf:e.part.leaf,
      worldVertices:e.world,screenVertices:e.screen,bounds:e.part.bounds,offsetY:offset(e.part)}))};
    root.dataset.ready='true';root.dataset.mode=state.mode;root.dataset.step=String(state.step);root.dataset.partCount=String(parts.length);
    root.dataset.rightAngle=String(angles().RIGHT);root.dataset.leftAngle=String(angles().LEFT);
    $('[data-scene-tag]').textContent=state.mode==='joint'?'Center detail · 11.811 in high crop':state.mode==='lap'?'Half-lap detail · 14.173 in cropped ends':state.mode==='build'?'Right leaf · construction sequence':state.mode==='leaf'?'Right leaf · assembly layers':state.camera==='inside'?'Inside view · leaf names follow the outside':'Right leaf active · dimensions follow outside view';
    $('[data-view-hint]').textContent=state.exploded?'Layers separated for inspection; separation distances are illustrative.':
      state.camera==='custom'?'Custom 3D view · choose a preset to reset.':
      state.dimensions&&!['front','inside','top'].includes(state.camera)?'Choose Front for overall dimension lines; select any part for its size.':state.mode==='lap'?'Lap cut dimension in cm · inspection sizes follow the unit selector.':'Inspection dimensions in '+state.units+' · workshop cuts and marks in cm.';
  }
  function refreshParts(){
    const available=makeParts().filter(visible);if(!available.some(p=>p.id===state.selected))state.selected=null;
    const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='Select a visible part…';
    const options=available.map(p=>{const el=document.createElement('option');el.value=p.id;el.textContent=(p.leaf==='RIGHT'?'R · ':'L · ')+p.label;return el;});
    partInput.replaceChildren(placeholder,...options);partInput.value=state.selected||'';
  }
  function updateDetails(){
    const p=makeParts().find(p=>p.id===state.selected);
    $('[data-part-title]').textContent=p?p.label:'Select a part';
    $('[data-part-size]').textContent=p?(p.role==='hardware'?'Reference only':p.crop?'Full blank: '+p.blank.map(fmt).join(' × ')+' '+state.units:sizeText(p)):'Tap the model or use the part list';
    $('[data-part-axis]').textContent=p?(p.crop?'Length × width × depth · ':p.role==='hardware'?'Product and dimensions unselected · ':'Width × height × depth · ')+(p.leaf==='RIGHT'?'right':'left')+' leaf'+(state.mode==='joint'?' · cropped section':''):'Inspection follows the unit selector. Cut instructions use cm.';
    $('[data-part-note]').textContent=p?descriptions[p.role]:'Separate the layers or choose Frame only to inspect the timber, skins and insulation.';
    $('[data-part-id]').textContent=p?'Part: '+p.id:'';
    partInput.value=state.selected||'';
  }
  function updateText(){
    const build=state.mode==='build';$('[data-step-label]').hidden=!build;$('[data-step-buttons]').hidden=!build;
    $('[data-step-title]').textContent=build?steps[state.step-1][0]:state.mode==='joint'?'Center connection':state.mode==='leaf'?'Inspect one leaf':state.mode==='lap'?'Complementary half-laps':'Two outward-opening leaves';
    instruction.textContent=build?steps[state.step-1][1]:state.mode==='joint'?
      'The white cover is fixed only to the right leaf. Its gasket presses on the left trim. Open the right leaf first; close the left first. Select the cover, spacer or gasket to inspect its measured geometry.':
      state.mode==='lap'?'The rail retains the outside half of the 1-1/2 in stock thickness. The matching stile notch removes the outside half over an 8.89 cm cut length. Cut each piece 1.905 cm deep so they assemble flush. Separate layers to inspect both cuts. Displayed ends are 14.173 in crops; select a piece for its full blank size.':
      state.mode==='leaf'?'Inspect the full frame, supported plywood edge strip and two insulation fields. Separate layers to see how the 2.169 in body is assembled. Workshop cut lengths and marks are in cm; stock sizes are imperial.':
      'For the assumed 257 × 216 cm opening, the reference cut size is 127.565 × 213.865 cm per leaf. Opening animation uses an illustrative hinge axis; actual hinges, fixings and the existing frame still require field verification.';
    const a=angles();openingValue.textContent=state.opening===0?'Closed':'Right '+Math.round(a.RIGHT)+'° · Left '+Math.round(a.LEFT)+'°';
    openingInput.value=String(state.opening);openingInput.setAttribute('aria-valuetext',openingValue.textContent);
    play.textContent=state.animating?'Pause':state.opening>=100?'Close doors':'Open doors';
    const disabled=state.exploded>0||state.layers!=='all'||state.mode==='lap'||(build&&state.step<8);openingInput.disabled=disabled;play.disabled=disabled;
    modeInput.value=state.mode;stepInput.value=String(state.step);explodeInput.checked=!!state.exploded;layerInput.value=state.layers;
    layerInput.disabled=build||['joint','lap'].includes(state.mode);$('[data-hardware]').disabled=['joint','lap','build'].includes(state.mode);$('[data-hardware]').checked=state.hardware;dimensionInput.checked=state.dimensions;unitInput.value=state.units;
    $('[data-prev]').disabled=state.step<=1;$('[data-next]').disabled=state.step>=8;
    updateDetails();
  }
  function stop(){sequence++;state.animating=false;}
  function setCamera(value='3d'){
    state.camera=value;angleInput.value=value;state.zoom=1;
    if(value==='top'){state.yaw=0;state.pitch=-Math.PI/2;}
    else if(value==='front'){state.yaw=0;state.pitch=0;}
    else if(value==='inside'){state.yaw=Math.PI;state.pitch=0;}
    else if(state.mode==='whole'){state.yaw=-.38;state.pitch=-.16;}
    else if(state.mode==='joint'){state.yaw=-.64;state.pitch=-.42;}
    else if(state.mode==='lap'){state.yaw=-.6;state.pitch=-.4;}
    else{state.yaw=-.7;state.pitch=-.21;}
    draw();
  }
  function setMode(mode){
    stop();state.mode=mode;state.opening=0;state.exploded=['leaf','lap'].includes(mode)?1:0;state.layers='all';state.selected=null;
    if(mode==='build'){state.step=1;state.exploded=0;}
    refreshParts();setCamera();updateText();draw();
  }
  function setStep(step){
    stop();state.mode='build';state.step=clamp(Number(step),1,8);state.opening=0;state.layers='all';state.selected=null;
    state.exploded=state.step>=2&&state.step<=7?1:0;refreshParts();setCamera();updateText();draw();
  }
  function setExploded(value){stop();state.opening=0;state.exploded=value?1:0;state.zoom=1;updateText();draw();}
  function setOpening(value){
    stop();if(state.mode!=='whole'){state.mode='whole';state.exploded=0;state.layers='all';refreshParts();setCamera();}
    state.opening=clamp(Number(value),0,100);updateText();draw();
  }
  function setLayers(value){stop();state.layers=value;state.opening=0;state.selected=null;refreshParts();updateText();draw();}
  function selectPart(id){state.selected=makeParts().filter(visible).some(p=>p.id===id)?id:null;updateDetails();draw();}
  function animateOpening(){
    if(state.animating){stop();updateText();return;}
    if(state.mode!=='whole'){state.mode='whole';state.exploded=0;state.layers='all';refreshParts();setCamera();}
    const from=state.opening,to=from>=100?0:100,id=++sequence;
    if(window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches){state.opening=to;updateText();draw();return;}
    state.animating=true;let start=null;updateText();
    function tick(t){if(id!==sequence)return;if(start===null)start=t;const p=Math.min(1,(t-start)/2200);state.opening=from+(to-from)*p;updateText();draw();if(p<1)requestAnimationFrame(tick);else{state.animating=false;updateText();}}
    requestAnimationFrame(tick);
  }
  function pick(x,y){
    if(!frame)return null;let hit=null,best=Infinity;
    for(const f of frame.faces){const a=f.points[0];for(let i=1;i<f.points.length-1;i++){
      const b=f.points[i],c=f.points[i+1],det=(b[1]-c[1])*(a[0]-c[0])+(c[0]-b[0])*(a[1]-c[1]);if(Math.abs(det)<1e-8)continue;
      const u=((b[1]-c[1])*(x-c[0])+(c[0]-b[0])*(y-c[1]))/det,v=((c[1]-a[1])*(x-c[0])+(a[0]-c[0])*(y-c[1]))/det,w=1-u-v;
      if(Math.min(u,v,w)<-.0001)continue;const depth=u*a[2]+v*b[2]+w*c[2];if(depth<best){best=depth;hit=f;}
    }}
    selectPart(hit?hit.id:null);return hit?hit.id:null;
  }
  modeInput.addEventListener('change',()=>setMode(modeInput.value));stepInput.addEventListener('change',()=>setStep(stepInput.value));angleInput.addEventListener('change',()=>setCamera(angleInput.value));
  explodeInput.addEventListener('change',()=>setExploded(explodeInput.checked));openingInput.addEventListener('input',()=>setOpening(openingInput.value));play.addEventListener('click',animateOpening);
  layerInput.addEventListener('change',()=>setLayers(layerInput.value));partInput.addEventListener('change',()=>selectPart(partInput.value));
  $('[data-hardware]').addEventListener('change',()=>{state.hardware=$('[data-hardware]').checked;refreshParts();updateText();draw();});
  unitInput.addEventListener('change',()=>{state.units=unitInput.value;updateText();draw();});
  dimensionInput.addEventListener('change',()=>{state.dimensions=dimensionInput.checked;state.zoom=1;draw();});
  $('[data-prev]').addEventListener('click',()=>setStep(state.step-1));$('[data-next]').addEventListener('click',()=>setStep(state.step+1));
  $('[data-fit]').addEventListener('click',()=>{state.zoom=1;draw();});
  const zoom=f=>{state.zoom=clamp(state.zoom*f,.6,3);draw();};$('[data-minus]').addEventListener('click',()=>zoom(1/1.2));$('[data-plus]').addEventListener('click',()=>zoom(1.2));
  canvas.addEventListener('wheel',e=>{e.preventDefault();zoom(Math.exp(-e.deltaY*.001));},{passive:false});
  const pointers=new Map();let gesture=null,pinch=0;
  canvas.addEventListener('pointerdown',e=>{pointers.set(e.pointerId,[e.clientX,e.clientY]);canvas.setPointerCapture(e.pointerId);gesture={x:e.clientX,y:e.clientY,moved:false};if(pointers.size===2){const p=[...pointers.values()];pinch=Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]);}});
  canvas.addEventListener('pointermove',e=>{if(!pointers.has(e.pointerId))return;const last=pointers.get(e.pointerId);pointers.set(e.pointerId,[e.clientX,e.clientY]);if(gesture&&Math.hypot(e.clientX-gesture.x,e.clientY-gesture.y)>4)gesture.moved=true;if(pointers.size===2){const p=[...pointers.values()],d=Math.hypot(p[0][0]-p[1][0],p[0][1]-p[1][1]);if(pinch)zoom(d/pinch);pinch=d;if(gesture)gesture.moved=true;}else{state.yaw+=(e.clientX-last[0])*.006;state.pitch=clamp(state.pitch+(e.clientY-last[1])*.005,-1.57,1.5);state.camera='custom';angleInput.value='custom';draw();}});
  const release=e=>{if(e.type==='pointerup'&&gesture&&!gesture.moved&&pointers.size===1){const r=canvas.getBoundingClientRect();pick(e.clientX-r.left,e.clientY-r.top);}pointers.delete(e.pointerId);gesture=null;pinch=0;};canvas.addEventListener('pointerup',release);canvas.addEventListener('pointercancel',release);
  new ResizeObserver(draw).observe(canvas);
  window.__garageExecution3D={constants:D,getState:()=>({...state,angles:angles()}),getParts:()=>makeParts(),getFrame:()=>frame,getPixels:()=>renderedPixels,
    setMode,setStep,setExploded,setOpening,setCamera,setLayers,selectPart,pick,draw,worldPoint:world};
  refreshParts();updateText();draw();
})();
