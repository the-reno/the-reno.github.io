#!/usr/bin/env python3
"""Assemble the offline V4 construction viewer from canonical CAD mesh data."""
import json
from pathlib import Path

root = Path(__file__).resolve().parent
mesh = json.loads((root.parent / "cad" / "preview_mesh.json").read_text())
script = (root / "viewer.js").read_text().replace("/*__CAD_JSON__*/null", json.dumps(mesh, separators=(",", ":")))
document = (root / "template.html").read_text().replace("/*__VIEWER_SCRIPT__*/", script)
output = root / "garage-door-execution-3d.html"
output.write_text(document)
print(json.dumps({"output": str(output), "bytes": output.stat().st_size, "canonical_parts": len(mesh["parts"])}))
